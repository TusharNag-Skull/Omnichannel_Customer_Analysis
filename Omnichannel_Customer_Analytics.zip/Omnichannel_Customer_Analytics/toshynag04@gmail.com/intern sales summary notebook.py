# Databricks notebook source
from pyspark.sql import SparkSession
from pyspark.sql.functions import sum as spark_sum , count , round , current_timestamp


# COMMAND ----------

from pyspark.sql import SparkSession
 
 
spark = SparkSession.builder .appName("InternTraining") .getOrCreate()
 
 
print(spark.version)

# COMMAND ----------

data = [(1, "Ravi"),(2, "John")]
 
df = spark.createDataFrame(data, ["id", "name"])
 
display(df)

# COMMAND ----------

from pyspark.sql.types import *


schema = StructType([

    StructField("id", IntegerType(), True),

    StructField("name", StringType(), True),

    StructField("salary", DoubleType(), True)

])

# COMMAND ----------

from pyspark.sql.functions import col
df_bonus = df.withColumn(

    "bonus",

    col("salary") * 0.10

)
 
 

# COMMAND ----------

