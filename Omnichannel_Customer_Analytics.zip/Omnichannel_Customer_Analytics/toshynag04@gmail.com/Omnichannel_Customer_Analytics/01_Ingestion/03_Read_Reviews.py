# Databricks notebook source
# ============================================================================
# STEP 1 : Read Reviews Dataset from AWS S3
# ============================================================================

order_reviews_df = (
    spark.read
        .option("header", "true")
        .option("inferSchema", "true")

        # Handle quoted text correctly
        .option("quote", '"')

        # Handle escaped quotes inside text
        .option("escape", '"')

        # Allow review comments to span multiple lines
        .option("multiLine", "true")

        .csv("s3://omnicapstone/raw_data/olist_order_reviews_dataset.csv")
)

order_reviews_df

# COMMAND ----------

order_reviews_df.printSchema()

print(order_reviews_df.count())

display(order_reviews_df.limit(10))

# COMMAND ----------

# # ============================================================================
# # STEP 2 : Display Sample Records
# #
# # Why?
# # ----
# # Before performing any profiling or validation, we inspect a few records
# # from the dataset.
# #
# # This helps us verify:
# # • Column names
# # • Sample values
# # • Overall data structure
# # • Whether the data has been read correctly
# # ============================================================================

# display(order_reviews_df)

# COMMAND ----------

# ============================================================================
# STEP 3 : Count Total Records
#
# Why?
# ----
# Counting the records confirms that the complete source file has been
# loaded successfully.
#
# This count will later be compared with the Bronze and Silver tables to
# ensure that no records are accidentally lost during processing.
# ============================================================================

review_count = order_reviews_df.count()

print(f"Total Order Review Records : {review_count}")

# COMMAND ----------

# ============================================================================
# STEP 4 : Print Dataset Schema
#
# Why?
# ----
# Understanding the schema helps verify:
# • Column names
# • Datatypes
# • Nullable fields
#
# Any datatype inconsistencies observed here will be addressed later in the
# Silver layer, where data cleansing and standardization take place.
# ============================================================================

order_reviews_df.printSchema()

# COMMAND ----------

# ============================================================================
# STEP 5 : Check Missing Values
#
# Why?
# ----
# Missing values are one of the most common data quality issues.
#
# Before loading the dataset into Bronze, we identify whether any important
# columns contain NULL values.
#
# This helps determine whether:
# • Data cleaning is required.
# • Missing values are expected business behavior.
# • Certain records need further investigation.
# ============================================================================

from pyspark.sql.functions import col, when, count

missing_values_df = order_reviews_df.select(

    [
        count(
            when(col(column).isNull(), column)
        ).alias(column)

        for column in order_reviews_df.columns
    ]

)

display(missing_values_df)

# COMMAND ----------

# ============================================================================
# STEP 6 : Check Duplicate Records
#
# Why?
# ----
# Duplicate records may occur due to repeated ingestion or source system
# issues.
#
# Before storing the dataset in the Bronze layer, we verify that every row
# is unique.
#
# If duplicates exist, they will be investigated in the Silver layer.
# ============================================================================

# Count total rows
total_rows = order_reviews_df.count()

# Count unique rows
distinct_rows = order_reviews_df.distinct().count()

# Calculate duplicate rows
duplicate_rows = total_rows - distinct_rows

print(f"Total Rows      : {total_rows}")
print(f"Distinct Rows   : {distinct_rows}")
print(f"Duplicate Rows  : {duplicate_rows}")

# COMMAND ----------

