# Databricks notebook source
# ============================================================================
# STEP 1 : Read Order Payments CSV from AWS S3
#
# Why?
# ----
# This is the ingestion step of our Medallion Architecture.
#
# We are reading the raw Order Payments dataset from AWS S3 into a Spark
# DataFrame so that it can be validated before loading it into the Bronze layer.
#
# inferSchema = Automatically detects the datatype of each column.
# header = Uses the first row of the CSV as column names.
# ============================================================================

order_payments_df = (
    spark.read
         .option("header", "true")          # Use first row as column names
         .option("inferSchema", "true")     # Automatically infer datatypes
         .csv("s3://omnicapstone/raw_data/olist_order_payments_dataset.csv")
)

# COMMAND ----------

# ============================================================================
# STEP 2 : Display the Raw Order Payments Dataset
#
# Why?
# ----
# Before loading data into the Bronze layer, we visually inspect the dataset.
#
# This helps us verify:
# • Column names
# • Data types
# • Sample records
# • Overall data quality
#
# display() provides an interactive table in Databricks.
# ============================================================================

display(order_payments_df)

# COMMAND ----------

# ============================================================================
# STEP 3 : Count Total Number of Records
#
# Why?
# ----
# Before loading data into the Bronze layer, every Data Engineer verifies
# the total number of records read from the source.
#
# This serves as the baseline for future validation.
# After loading into Bronze and Silver, the record count should match unless
# business transformations intentionally remove records.
# ============================================================================

payment_count = order_payments_df.count()

print(f"Total Order Payment Records : {payment_count}")

# COMMAND ----------

# ============================================================================
# STEP 4 : Inspect the Dataset Schema
#
# Why?
# ----
# Understanding the schema is one of the first tasks of a Data Engineer.
#
# This helps us:
# 1. Verify every column is present.
# 2. Verify datatypes were inferred correctly.
# 3. Identify columns that may require cleaning later.
#
# In this dataset we expect:
# - order_id               -> string
# - payment_sequential     -> integer
# - payment_type           -> string
# - payment_installments   -> integer
# - payment_value          -> double
# ============================================================================

order_payments_df.printSchema()

# COMMAND ----------

from pyspark.sql.functions import col, when, count

# ============================================================================
# STEP 5 : Check Missing (NULL) Values
#
# Why?
# ----
# Missing values are one of the most common data quality issues.
#
# Before loading data into the Bronze layer, we identify how many NULL values
# exist in every column.
#
# Bronze stores raw data, so we generally DO NOT remove NULLs here.
# We simply profile the dataset so that cleaning decisions can be made later
# in the Silver layer.
# ============================================================================

missing_values_df = order_payments_df.select(

    [
        count(
            when(col(column).isNull(), column)
        ).alias(column)

        for column in order_payments_df.columns
    ]

)

display(missing_values_df)

# COMMAND ----------

# ============================================================================
# STEP 6 : Check for Duplicate Records
#
# Why?
# ----
# Duplicate records can occur because of:
# - Multiple file loads
# - Pipeline failures
# - Source system issues
#
# Since Bronze stores raw data, we don't remove duplicates here.
# We simply measure them and document the findings.
#
# Here we compare:
# Total Records
# vs
# Distinct Records
# ============================================================================
# Count total rows
total_rows = order_payments_df.count()

# Count unique rows
distinct_rows = order_payments_df.distinct().count()

# Calculate duplicate rows
duplicate_rows = total_rows - distinct_rows

print(f"Total Rows      : {total_rows}")
print(f"Distinct Rows   : {distinct_rows}")
print(f"Duplicate Rows  : {duplicate_rows}")

# COMMAND ----------

