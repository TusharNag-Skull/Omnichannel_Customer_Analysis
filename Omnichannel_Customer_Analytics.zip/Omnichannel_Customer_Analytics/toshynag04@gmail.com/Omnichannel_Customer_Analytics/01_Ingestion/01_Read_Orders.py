# Databricks notebook source
spark.read.csv("s3://omnicapstone/raw_data/...")

# COMMAND ----------

orders_df = (
    spark.read
        .option("header", "true")
        .option("inferSchema", "true")
        .csv("s3://omnicapstone/raw_data/olist_orders_dataset.csv")
)

# COMMAND ----------

display(orders_df)

# COMMAND ----------

# ---------------------------------------------
# Count total number of records
#
# Why?
# Before loading data into Bronze, every Data Engineer
# verifies that the number of records read from the source
# matches the expected number.
#
# This helps detect partial loads or missing files.
# ---------------------------------------------

orders_count = orders_df.count()

print(f"Total Orders Records: {orders_count}")

# COMMAND ----------

# ===========================================================
# STEP 9 : Inspect the Schema
# ===========================================================
#
# Why?
# ----
# The schema tells us:
#
# • Column Names
# • Data Types
# • Nullable Columns
#
# Before performing any transformation,
# a Data Engineer always validates that
# the schema matches the expected business schema.
#
# This also helps identify columns that may require
# datatype conversion during the Silver layer.
#
# Interview Question:
# "Why do you inspect the schema after ingestion?"
#
# Answer:
# "To ensure that Spark has inferred the correct data
# types and to identify columns that require validation
# or transformation before downstream processing."
# ===========================================================

orders_df.printSchema()

# COMMAND ----------

# ===========================================================
# STEP 10 : Check NULL Values
# ===========================================================
#
# Why?
# ----
# Before storing data into the Bronze layer,
# we want to understand the quality of the incoming data.
#
# We DO NOT clean anything here.
#
# We simply identify:
#
# • Which columns contain NULL values
# • How many NULL values exist
#
# This information helps us decide what transformations
# will be required in the Silver layer.
#
# Interview Tip:
#
# Bronze = Observation
# Silver = Transformation
#
# ===========================================================

from pyspark.sql.functions import col, when, count

# Count NULL values in every column
null_df = orders_df.select(
    [
        count(when(col(column).isNull(), column)).alias(column)
        for column in orders_df.columns
    ]
)

display(null_df)

# COMMAND ----------

# ===========================================================
# STEP 11 : Duplicate Record Analysis
# ===========================================================
#
# Why?
# ----
# Before loading data into the Bronze layer,
# we want to understand whether the source file
# already contains duplicate records.
#
# NOTE:
# We are NOT removing duplicates here.
#
# Bronze Layer = Raw Copy
#
# We only measure the number of duplicate rows.
#
# If duplicates exist, we will decide in the
# Silver layer whether they should be removed
# based on business requirements.
# ===========================================================

# Count total rows
total_rows = orders_df.count()

# Count distinct rows
distinct_rows = orders_df.distinct().count()

# Calculate duplicate rows
duplicate_rows = total_rows - distinct_rows

print(f"Total Rows      : {total_rows}")
print(f"Distinct Rows   : {distinct_rows}")
print(f"Duplicate Rows  : {duplicate_rows}")

# COMMAND ----------

# MAGIC %sql SHOW SCHEMAS;

# COMMAND ----------

# MAGIC %sql
# MAGIC SHOW CATALOGS;

# COMMAND ----------

