# Databricks notebook source
# =====================================================================
# STEP 1 : Read the Bronze Order Reviews Table
#
# Why?
# ----
# The Bronze layer contains the raw Order Reviews data stored as a Delta
# table. We load it into a DataFrame before applying data quality
# improvements in the Silver layer.
#
# The Silver layer is responsible for:
# • Data type standardization
# • Duplicate removal
# • Missing value handling
# • Data quality validation
# =====================================================================

bronze_order_reviews_df = spark.table("workspace.bronze.order_reviews")

bronze_order_reviews_df

# COMMAND ----------

# =====================================================================
# STEP 2 : Dataset Overview
#
# Why?
# ----
# Before cleaning the data, we inspect the dataset to understand its
# overall size and structure.
#
# This helps us:
# • Verify that the Bronze table loaded correctly.
# • Count the total number of records.
# • Count the total number of columns.
# • Verify the schema before transformations.
# =====================================================================

print(f"Total Records : {bronze_order_reviews_df.count()}")
print(f"Total Columns : {len(bronze_order_reviews_df.columns)}")

print("\nSchema Information")

bronze_order_reviews_df.printSchema()

# COMMAND ----------

# =====================================================================
# STEP 3 : Create the Silver DataFrame
#
# Why?
# ----
# We create a separate DataFrame for the Silver layer so that the
# original Bronze DataFrame remains unchanged.
#
# All data cleaning, validation, and quality improvements will be
# performed on this Silver DataFrame.
#
# This follows the Medallion Architecture principle where:
# Bronze = Raw Data
# Silver = Cleaned Data
# =====================================================================

silver_reviews_df = bronze_order_reviews_df

silver_reviews_df

# COMMAND ----------

# =====================================================================
# STEP 4 : Check Missing Values
#
# Why?
# ----
# Missing values reduce data quality and can affect downstream analytics.
#
# Before performing any cleaning, we identify how many NULL values are
# present in each column.
#
# This helps us decide:
# • Which columns require cleaning.
# • Which columns can safely retain NULL values.
# • Whether missing values are acceptable from a business perspective.
# =====================================================================

from pyspark.sql.functions import col, sum, when

missing_values_df = silver_reviews_df.select([
    sum(when(col(c).isNull(), 1).otherwise(0)).alias(c)
    for c in silver_reviews_df.columns
])

missing_values_df.show()

# COMMAND ----------

# =====================================================================
# STEP 5 : Check Duplicate Records
#
# Why?
# ----
# Duplicate records can lead to inaccurate reporting and analytics.
#
# Before removing duplicates, we calculate:
# • Total number of records.
# • Number of unique records.
# • Number of duplicate records.
#
# The Silver layer removes duplicate rows to improve data quality.
# =====================================================================

total_rows = silver_reviews_df.count()
distinct_rows = silver_reviews_df.distinct().count()

duplicate_rows = total_rows - distinct_rows

print(f"Total Rows      : {total_rows}")
print(f"Distinct Rows   : {distinct_rows}")
print(f"Duplicate Rows  : {duplicate_rows}")

# COMMAND ----------

# =====================================================================
# STEP 6 : Data Quality Validation
#
# Why?
# ----
# Even if there are no missing values in critical columns, we should
# validate that the business data itself is valid.
#
# We check:
# • Review score is between 1 and 5.
# • Review answer timestamp is not earlier than review creation date.
# =====================================================================

from pyspark.sql.functions import col

silver_reviews_df = (
    silver_reviews_df
    .withColumn(
        "invalid_review_score_flag",
        ~col("review_score").between(1, 5)
    )
    .withColumn(
        "invalid_review_date_flag",
        col("review_answer_timestamp") < col("review_creation_date")
    )
)

silver_reviews_df.select(
    "review_score",
    "review_creation_date",
    "review_answer_timestamp",
    "invalid_review_score_flag",
    "invalid_review_date_flag"
).show(10, truncate=False)

# COMMAND ----------

# =====================================================================
# STEP 7 : Count Invalid Records
#
# Why?
# ----
# After creating the validation flags, we count how many records violate
# our business rules.
#
# Validation Rules:
# • Review score must be between 1 and 5.
# • Review answer timestamp cannot be earlier than review creation date.
# =====================================================================

from pyspark.sql.functions import col

silver_reviews_df.groupBy("invalid_review_score_flag").count().show()

silver_reviews_df.groupBy("invalid_review_date_flag").count().show()

# COMMAND ----------

# =====================================================================
# STEP 8 : Create the Silver Schema
#
# Why?
# ----
# The Silver schema stores the cleaned and standardized datasets.
#
# Creating the schema ensures that all Silver Delta tables are organized
# separately from the Bronze layer.
#
# Using CREATE SCHEMA IF NOT EXISTS allows this notebook to be rerun
# safely without causing errors if the schema already exists.
# =====================================================================

spark.sql("""
CREATE SCHEMA IF NOT EXISTS workspace.silver
""")

print("✅ Silver schema created successfully.")

# COMMAND ----------

# =====================================================================
# STEP 9 : Create the Silver Order Reviews Delta Table
#
# Why?
# ----
# The Silver Delta table stores the cleaned and standardized Order
# Reviews dataset.
#
# Compared to the Bronze table:
# • Data types have been corrected.
# • Business validation flags are included.
# • The dataset is ready for downstream analytics.
#
# Using Delta format provides:
# • ACID transactions
# • Schema enforcement
# • Time travel
# • Efficient updates and reads
# =====================================================================

spark.sql("""

CREATE TABLE IF NOT EXISTS workspace.silver.order_reviews
(

    review_id STRING,
    order_id STRING,
    review_score INT,
    review_comment_title STRING,
    review_comment_message STRING,
    review_creation_date TIMESTAMP,
    review_answer_timestamp TIMESTAMP,

    invalid_review_score_flag BOOLEAN,
    invalid_review_date_flag BOOLEAN

)

USING DELTA

""")

print("✅ Silver Order Reviews Delta table created successfully.")

# COMMAND ----------

# ============================================================================
# STEP 10 : Load Data into the Silver Delta Table
#
# Why?
# -----
# After completing all validation and data quality checks, we load the
# cleaned Order Reviews dataset into the Silver Delta table.
#
# The Silver table contains:
# • Correct data types
# • Business validation flags
# • Clean and standardized records
#
# Overwrite mode is used so that rerunning the notebook refreshes the
# Silver table with the latest cleaned data.
# ============================================================================

silver_reviews_df.write \
    .mode("overwrite") \
    .insertInto("workspace.silver.order_reviews")

print("✅ Order Reviews data successfully loaded into the Silver Delta table.")

# COMMAND ----------

# ============================================================================
# STEP 11 : Verify the Silver Delta Table
#
# Why?
# -----
# After loading the cleaned data into the Silver Delta table, we verify
# that the table contains the expected records and schema.
#
# This confirms:
# • Data was loaded successfully.
# • Data types are correct.
# • Validation flag columns are present.
# ============================================================================

silver_reviews_df = spark.table("workspace.silver.order_reviews")

silver_reviews_df.printSchema()

display(silver_reviews_df.limit(10))

# COMMAND ----------

# ============================================================================
# STEP 12 : Validate Record Count
#
# Why?
# -----
# Compare the number of records in the Bronze layer with the Silver layer
# to ensure that no records were unintentionally lost during the
# transformation process.
#
# Since this dataset contained no invalid records and no duplicates after
# fixing the ingestion process, both layers should contain the same number
# of records.
# ============================================================================

bronze_count = bronze_order_reviews_df.count()
silver_count = silver_reviews_df.count()

print(f"Bronze Records : {bronze_count}")
print(f"Silver Records : {silver_count}")

if bronze_count == silver_count:
    print("✅ Validation Passed: Row counts match.")
else:
    print("❌ Validation Failed: Row counts do not match.")

# COMMAND ----------

# MAGIC %sql
# MAGIC
# MAGIC DESCRIBE HISTORY workspace.silver.order_reviews;
# MAGIC
# MAGIC
# MAGIC -- Why are we doing this?
# MAGIC
# MAGIC -- Delta Lake automatically records every operation performed on a Delta table.
# MAGIC
# MAGIC -- This allows us to:
# MAGIC
# MAGIC -- Track all write operations
# MAGIC -- See when the table was created or updated
# MAGIC -- Identify who performed the operation
# MAGIC -- Support auditing
# MAGIC -- Enable Time Travel and rollback if needed

# COMMAND ----------

# MAGIC %sql
# MAGIC
# MAGIC SHOW TABLES IN workspace.silver;

# COMMAND ----------

# ============================================================================
# STEP 15 : Export Silver Reviews Delta Table to Amazon S3
#
# Why?
# -----
# Besides registering the Delta table in Unity Catalog, we also store
# its physical Delta files in Amazon S3.
#
# This provides:
# • Durable cloud storage
# • Backup of the Silver layer
# • Easy access for downstream data pipelines
# • Separation between catalog metadata and physical storage
# ============================================================================

# Read Silver Delta table
silver_reviews_df = spark.table("workspace.silver.order_reviews")

# Export Delta files to Amazon S3
silver_reviews_df.write \
    .format("delta") \
    .mode("overwrite") \
    .save("s3://omnicapstone/silver_tables/order_reviews")

print("✅ Silver Order Reviews Delta table exported to S3 successfully.")

# COMMAND ----------

# MAGIC %md
# MAGIC # Silver Layer – Order Reviews
# MAGIC
# MAGIC ## Overview
# MAGIC
# MAGIC The **Silver layer** is the second layer of the Medallion Architecture.
# MAGIC
# MAGIC Its primary objective is to transform the raw Bronze data into a **clean, standardized, and analytics-ready dataset**.
# MAGIC
# MAGIC Unlike the Bronze layer, which stores the data exactly as it was received, the Silver layer performs:
# MAGIC
# MAGIC - Data quality validation
# MAGIC - Standardization of datatypes
# MAGIC - Business rule validation
# MAGIC - Duplicate verification
# MAGIC - Creation of quality flags
# MAGIC
# MAGIC The final dataset is stored as a **Delta Table**, registered in the **Unity Catalog**, and exported to **Amazon S3**.
# MAGIC
# MAGIC ---
# MAGIC
# MAGIC # Source
# MAGIC
# MAGIC The Silver notebook reads data from the Bronze Delta table:
# MAGIC
# MAGIC ```
# MAGIC workspace.bronze.order_reviews
# MAGIC ```
# MAGIC
# MAGIC Since the Bronze ingestion notebook was corrected to properly parse multiline CSV records, the Silver layer now receives a clean source dataset with correctly inferred datatypes.
# MAGIC
# MAGIC ---
# MAGIC
# MAGIC # Step 1 : Read Bronze Order Reviews Table
# MAGIC
# MAGIC ## What we did
# MAGIC
# MAGIC The Bronze Delta table was loaded into a Spark DataFrame.
# MAGIC
# MAGIC ```python
# MAGIC spark.table("workspace.bronze.order_reviews")
# MAGIC ```
# MAGIC
# MAGIC ## Why?
# MAGIC
# MAGIC Instead of reading the raw CSV again, the Silver layer always starts from the Bronze Delta table because:
# MAGIC
# MAGIC - Bronze already preserves the raw data.
# MAGIC - Delta tables provide ACID guarantees.
# MAGIC - Reading Delta tables is faster than repeatedly parsing CSV files.
# MAGIC - All downstream transformations originate from the Bronze layer.
# MAGIC
# MAGIC ---
# MAGIC
# MAGIC # Step 2 : Explore the Dataset
# MAGIC
# MAGIC ## What we checked
# MAGIC
# MAGIC We inspected:
# MAGIC
# MAGIC - Total number of records
# MAGIC - Total number of columns
# MAGIC - Dataset schema
# MAGIC
# MAGIC Output
# MAGIC
# MAGIC | Metric | Value |
# MAGIC |---------|------:|
# MAGIC | Total Records | **99,224** |
# MAGIC | Total Columns | **7** |
# MAGIC
# MAGIC Schema
# MAGIC
# MAGIC | Column | Data Type |
# MAGIC |---------|-----------|
# MAGIC | review_id | STRING |
# MAGIC | order_id | STRING |
# MAGIC | review_score | INTEGER |
# MAGIC | review_comment_title | STRING |
# MAGIC | review_comment_message | STRING |
# MAGIC | review_creation_date | TIMESTAMP |
# MAGIC | review_answer_timestamp | TIMESTAMP |
# MAGIC
# MAGIC ---
# MAGIC
# MAGIC ## Why?
# MAGIC
# MAGIC This verifies that:
# MAGIC
# MAGIC - Bronze loaded successfully.
# MAGIC - Expected number of records exist.
# MAGIC - Datatypes are already standardized.
# MAGIC - Downstream transformations can safely use these datatypes.
# MAGIC
# MAGIC ---
# MAGIC
# MAGIC # Step 3 : Create Silver DataFrame
# MAGIC
# MAGIC ## What we did
# MAGIC
# MAGIC A working copy of the Bronze DataFrame was created.
# MAGIC
# MAGIC ```python
# MAGIC silver_reviews_df = bronze_order_reviews_df
# MAGIC ```
# MAGIC
# MAGIC ---
# MAGIC
# MAGIC ## Why?
# MAGIC
# MAGIC This allows us to perform transformations on the Silver dataset without modifying the Bronze data.
# MAGIC
# MAGIC The Bronze layer always remains immutable.
# MAGIC
# MAGIC ---
# MAGIC
# MAGIC # Step 4 : Check Missing Values
# MAGIC
# MAGIC ## What we checked
# MAGIC
# MAGIC Missing values were calculated for every column.
# MAGIC
# MAGIC Output
# MAGIC
# MAGIC | Column | Missing Values |
# MAGIC |---------|---------------:|
# MAGIC | review_id | 0 |
# MAGIC | order_id | 0 |
# MAGIC | review_score | 0 |
# MAGIC | review_comment_title | **87,656** |
# MAGIC | review_comment_message | **58,247** |
# MAGIC | review_creation_date | 0 |
# MAGIC | review_answer_timestamp | 0 |
# MAGIC
# MAGIC ---
# MAGIC
# MAGIC ## Why?
# MAGIC
# MAGIC Checking missing values helps us understand data completeness.
# MAGIC
# MAGIC Not every missing value is a data quality issue.
# MAGIC
# MAGIC For example:
# MAGIC
# MAGIC - Many customers simply do not provide a review title.
# MAGIC - Some customers only provide a rating without a written review.
# MAGIC
# MAGIC These NULL values are therefore expected and are preserved.
# MAGIC
# MAGIC ---
# MAGIC
# MAGIC # Step 5 : Check Duplicate Records
# MAGIC
# MAGIC ## What we checked
# MAGIC
# MAGIC We compared:
# MAGIC
# MAGIC - Total rows
# MAGIC - Distinct rows
# MAGIC
# MAGIC Output
# MAGIC
# MAGIC | Metric | Value |
# MAGIC |---------|------:|
# MAGIC | Total Rows | **99,224** |
# MAGIC | Distinct Rows | **99,224** |
# MAGIC | Duplicate Rows | **0** |
# MAGIC
# MAGIC ---
# MAGIC
# MAGIC ## Why?
# MAGIC
# MAGIC Duplicate records can:
# MAGIC
# MAGIC - Inflate reports
# MAGIC - Distort KPIs
# MAGIC - Affect machine learning models
# MAGIC - Produce inaccurate business metrics
# MAGIC
# MAGIC Since duplicates are already absent after the corrected ingestion, no records needed removal.
# MAGIC
# MAGIC ---
# MAGIC
# MAGIC # Step 6 : Perform Business Rule Validation
# MAGIC
# MAGIC The Silver layer validates important business rules without deleting data.
# MAGIC
# MAGIC Instead, validation flags are created.
# MAGIC
# MAGIC ---
# MAGIC
# MAGIC ## Validation 1 — Review Score Validation
# MAGIC
# MAGIC ### Rule
# MAGIC
# MAGIC ```
# MAGIC Review Score must be between 1 and 5.
# MAGIC ```
# MAGIC
# MAGIC A new column was created:
# MAGIC
# MAGIC ```
# MAGIC invalid_review_score_flag
# MAGIC ```
# MAGIC
# MAGIC Meaning
# MAGIC
# MAGIC | Value | Interpretation |
# MAGIC |--------|---------------|
# MAGIC | FALSE | Valid review score |
# MAGIC | TRUE | Invalid review score |
# MAGIC
# MAGIC ---
# MAGIC
# MAGIC ### Result
# MAGIC
# MAGIC | Status | Count |
# MAGIC |--------|------:|
# MAGIC | Valid | **99,224** |
# MAGIC | Invalid | **0** |
# MAGIC
# MAGIC ---
# MAGIC
# MAGIC ## Why?
# MAGIC
# MAGIC Ratings outside the allowed range indicate corrupted or invalid data.
# MAGIC
# MAGIC Keeping a validation flag instead of deleting records:
# MAGIC
# MAGIC - preserves raw information,
# MAGIC - allows auditing,
# MAGIC - supports future investigation.
# MAGIC
# MAGIC ---
# MAGIC
# MAGIC # Validation 2 — Review Date Validation
# MAGIC
# MAGIC ### Rule
# MAGIC
# MAGIC ```
# MAGIC Review Answer Timestamp
# MAGIC must be greater than or equal to
# MAGIC
# MAGIC Review Creation Date
# MAGIC ```
# MAGIC
# MAGIC New column created:
# MAGIC
# MAGIC ```
# MAGIC invalid_review_date_flag
# MAGIC ```
# MAGIC
# MAGIC Meaning
# MAGIC
# MAGIC | Value | Interpretation |
# MAGIC |--------|---------------|
# MAGIC | FALSE | Valid timestamp sequence |
# MAGIC | TRUE | Invalid timestamp sequence |
# MAGIC
# MAGIC ---
# MAGIC
# MAGIC ### Result
# MAGIC
# MAGIC | Status | Count |
# MAGIC |--------|------:|
# MAGIC | Valid | **99,224** |
# MAGIC | Invalid | **0** |
# MAGIC
# MAGIC ---
# MAGIC
# MAGIC ## Why?
# MAGIC
# MAGIC A customer cannot receive a review response before creating the review.
# MAGIC
# MAGIC This validation identifies inconsistent timelines that may indicate data corruption.
# MAGIC
# MAGIC ---
# MAGIC
# MAGIC # Step 7 : Validation Summary
# MAGIC
# MAGIC Final validation counts
# MAGIC
# MAGIC ### Review Score
# MAGIC
# MAGIC | Flag | Count |
# MAGIC |------|------:|
# MAGIC | FALSE | **99,224** |
# MAGIC | TRUE | **0** |
# MAGIC
# MAGIC ---
# MAGIC
# MAGIC ### Review Dates
# MAGIC
# MAGIC | Flag | Count |
# MAGIC |------|------:|
# MAGIC | FALSE | **99,224** |
# MAGIC | TRUE | **0** |
# MAGIC
# MAGIC ---
# MAGIC
# MAGIC ## Why?
# MAGIC
# MAGIC This provides a quick summary of overall dataset quality.
# MAGIC
# MAGIC Since no invalid records exist, all reviews successfully passed the business validation rules.
# MAGIC
# MAGIC ---
# MAGIC
# MAGIC # Step 8 : Create Silver Schema
# MAGIC
# MAGIC A schema was created:
# MAGIC
# MAGIC ```
# MAGIC workspace.silver
# MAGIC ```
# MAGIC
# MAGIC ---
# MAGIC
# MAGIC ## Why?
# MAGIC
# MAGIC Separating Bronze and Silver tables improves:
# MAGIC
# MAGIC - Organization
# MAGIC - Security
# MAGIC - Governance
# MAGIC - Maintainability
# MAGIC
# MAGIC Using
# MAGIC
# MAGIC ```sql
# MAGIC CREATE SCHEMA IF NOT EXISTS
# MAGIC ```
# MAGIC
# MAGIC makes the notebook safely rerunnable.
# MAGIC
# MAGIC ---
# MAGIC
# MAGIC # Step 9 : Create Silver Delta Table
# MAGIC
# MAGIC The cleaned dataset was stored in:
# MAGIC
# MAGIC ```
# MAGIC workspace.silver.order_reviews
# MAGIC ```
# MAGIC
# MAGIC Columns
# MAGIC
# MAGIC | Column | Type |
# MAGIC |---------|------|
# MAGIC | review_id | STRING |
# MAGIC | order_id | STRING |
# MAGIC | review_score | INT |
# MAGIC | review_comment_title | STRING |
# MAGIC | review_comment_message | STRING |
# MAGIC | review_creation_date | TIMESTAMP |
# MAGIC | review_answer_timestamp | TIMESTAMP |
# MAGIC | invalid_review_score_flag | BOOLEAN |
# MAGIC | invalid_review_date_flag | BOOLEAN |
# MAGIC
# MAGIC ---
# MAGIC
# MAGIC ## Why?
# MAGIC
# MAGIC The Silver table contains:
# MAGIC
# MAGIC - Standardized datatypes
# MAGIC - Validation flags
# MAGIC - Clean data
# MAGIC - Analytics-ready records
# MAGIC
# MAGIC Using Delta format provides:
# MAGIC
# MAGIC - ACID transactions
# MAGIC - Schema enforcement
# MAGIC - Version history
# MAGIC - Time Travel
# MAGIC - Better performance
# MAGIC
# MAGIC ---
# MAGIC
# MAGIC # Step 10 : Load Data into Silver Delta Table
# MAGIC
# MAGIC The cleaned DataFrame was written into the Silver Delta table using:
# MAGIC
# MAGIC ```
# MAGIC Overwrite Mode
# MAGIC ```
# MAGIC
# MAGIC ---
# MAGIC
# MAGIC ## Why?
# MAGIC
# MAGIC Overwrite mode allows the notebook to be rerun safely while always refreshing the Silver table with the latest validated data.
# MAGIC
# MAGIC ---
# MAGIC
# MAGIC # Step 11 : Verify Silver Table
# MAGIC
# MAGIC The newly created Delta table was read back.
# MAGIC
# MAGIC Verification confirmed:
# MAGIC
# MAGIC - Correct schema
# MAGIC - Correct datatypes
# MAGIC - Validation columns present
# MAGIC - Data loaded successfully
# MAGIC
# MAGIC ---
# MAGIC
# MAGIC ## Why?
# MAGIC
# MAGIC This confirms that:
# MAGIC
# MAGIC - the write operation succeeded,
# MAGIC - no datatype conversions were lost,
# MAGIC - the final Silver table is correct.
# MAGIC
# MAGIC ---
# MAGIC
# MAGIC # Step 12 : Validate Record Count
# MAGIC
# MAGIC We compared:
# MAGIC
# MAGIC | Layer | Records |
# MAGIC |--------|--------:|
# MAGIC | Bronze | **99,224** |
# MAGIC | Silver | **99,224** |
# MAGIC
# MAGIC Result
# MAGIC
# MAGIC ```
# MAGIC Validation Passed
# MAGIC ```
# MAGIC
# MAGIC ---
# MAGIC
# MAGIC ## Why?
# MAGIC
# MAGIC This ensures:
# MAGIC
# MAGIC - no records were accidentally removed,
# MAGIC - no data loss occurred,
# MAGIC - the transformation process preserved all valid records.
# MAGIC
# MAGIC ---
# MAGIC
# MAGIC # Step 13 : Review Delta Table History
# MAGIC
# MAGIC We executed:
# MAGIC
# MAGIC ```sql
# MAGIC DESCRIBE HISTORY workspace.silver.order_reviews;
# MAGIC ```
# MAGIC
# MAGIC Delta History showed:
# MAGIC
# MAGIC - Table Creation
# MAGIC - Write Operation
# MAGIC - Timestamp
# MAGIC - User
# MAGIC - Version
# MAGIC - Operation Metrics
# MAGIC
# MAGIC ---
# MAGIC
# MAGIC ## Why?
# MAGIC
# MAGIC Delta History provides:
# MAGIC
# MAGIC - auditing,
# MAGIC - lineage,
# MAGIC - version tracking,
# MAGIC - rollback capability,
# MAGIC - Time Travel support.
# MAGIC
# MAGIC ---
# MAGIC
# MAGIC # Step 14 : Verify Table Registration
# MAGIC
# MAGIC Executed
# MAGIC
# MAGIC ```sql
# MAGIC SHOW TABLES IN workspace.silver;
# MAGIC ```
# MAGIC
# MAGIC Verified
# MAGIC
# MAGIC ```
# MAGIC order_reviews
# MAGIC ```
# MAGIC
# MAGIC exists inside the Silver schema.
# MAGIC
# MAGIC ---
# MAGIC
# MAGIC ## Why?
# MAGIC
# MAGIC This confirms the table has been successfully registered in the Unity Catalog and is available for downstream notebooks.
# MAGIC
# MAGIC ---
# MAGIC
# MAGIC # Step 15 : Export Silver Delta Table to Amazon S3
# MAGIC
# MAGIC The physical Delta files were exported to:
# MAGIC
# MAGIC ```
# MAGIC s3://omnicapstone/silver_tables/order_reviews/
# MAGIC ```
# MAGIC
# MAGIC ---
# MAGIC
# MAGIC ## Why?
# MAGIC
# MAGIC Exporting Delta files provides:
# MAGIC
# MAGIC - Durable cloud storage
# MAGIC - Physical backup
# MAGIC - Easy access for downstream pipelines
# MAGIC - Separation of Unity Catalog metadata from physical storage
# MAGIC - Disaster recovery support
# MAGIC
# MAGIC ---
# MAGIC
# MAGIC # Silver Layer Summary
# MAGIC
# MAGIC Final Table
# MAGIC
# MAGIC ```
# MAGIC workspace.silver.order_reviews
# MAGIC ```
# MAGIC
# MAGIC Physical Storage
# MAGIC
# MAGIC ```
# MAGIC s3://omnicapstone/silver_tables/order_reviews/
# MAGIC ```
# MAGIC
# MAGIC Final Record Count
# MAGIC
# MAGIC **99,224**
# MAGIC
# MAGIC Additional Columns Created
# MAGIC
# MAGIC - invalid_review_score_flag
# MAGIC - invalid_review_date_flag
# MAGIC
# MAGIC ---
# MAGIC
# MAGIC # Data Quality Summary
# MAGIC
# MAGIC | Check | Status |
# MAGIC |--------|--------|
# MAGIC | Missing Value Analysis | ✅ Completed |
# MAGIC | Duplicate Verification | ✅ No duplicates found |
# MAGIC | Review Score Validation | ✅ Passed |
# MAGIC | Review Date Validation | ✅ Passed |
# MAGIC | Datatype Standardization | ✅ Completed |
# MAGIC | Delta Table Created | ✅ Completed |
# MAGIC | Unity Catalog Registration | ✅ Completed |
# MAGIC | Delta History Verified | ✅ Completed |
# MAGIC | Record Count Validation | ✅ Passed |
# MAGIC | Export to Amazon S3 | ✅ Completed |
# MAGIC
# MAGIC ---
# MAGIC
# MAGIC # Outcome
# MAGIC
# MAGIC At the end of this notebook:
# MAGIC
# MAGIC - The Bronze Order Reviews dataset was successfully transformed into a clean Silver dataset.
# MAGIC - Datatypes were standardized and preserved.
# MAGIC - Business validation flags were added for future monitoring.
# MAGIC - Data quality checks confirmed that all records are valid.
# MAGIC - The Silver Delta table was successfully created and registered in Unity Catalog.
# MAGIC - Physical Delta files were exported to Amazon S3.
# MAGIC - The dataset is now fully prepared for building Gold-layer business models, KPIs, dashboards, and analytical data marts.

# COMMAND ----------

