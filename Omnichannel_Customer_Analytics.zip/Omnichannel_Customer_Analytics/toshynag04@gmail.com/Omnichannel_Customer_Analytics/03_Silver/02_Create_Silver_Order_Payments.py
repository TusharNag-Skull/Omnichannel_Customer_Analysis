# Databricks notebook source
# ============================================================================
# STEP 1 : Read Bronze Order Payments Delta Table
#
# Why?
# ----
# The Silver layer always starts by reading data from the Bronze layer.
#
# Bronze contains the raw source data stored in Delta format.
# Silver performs data quality validation and creates a cleaner dataset for
# downstream analytics.
#
# Reading from Bronze ensures that every downstream layer uses the same
# trusted source of data.
# ============================================================================

bronze_order_payments_df = spark.table("workspace.bronze.order_payments")

# Display the inferred schema
bronze_order_payments_df

# COMMAND ----------

# ============================================================================
# STEP 2 : Profile the Bronze Dataset
#
# Why?
# ----
# Before performing any transformations, a Data Engineer profiles the
# incoming dataset.
#
# This helps us understand:
# • Total number of records
# • Total number of columns
# • Column names and datatypes
#
# These metrics act as a baseline before data quality checks begin.
# ============================================================================

# Count total records
total_records = bronze_order_payments_df.count()

# Count total columns
total_columns = len(bronze_order_payments_df.columns)

print(f"Total Records : {total_records}")
print(f"Total Columns : {total_columns}")

print("\nSchema Information")
bronze_order_payments_df.printSchema()

# COMMAND ----------

# ============================================================================
# STEP 3 : Check Missing Values
#
# Why?
# ----
# Missing values are one of the most common data quality issues.
#
# Before cleaning the data, we identify whether any important columns
# contain NULL values.
#
# This helps us decide:
# • Whether records should be removed
# • Whether values should be replaced
# • Whether the NULLs are expected business behavior
# ============================================================================

from pyspark.sql.functions import col, when, count

# Count NULL values in every column
missing_values_df = bronze_order_payments_df.select(

    [
        count(
            when(col(column).isNull(), column)
        ).alias(column)

        for column in bronze_order_payments_df.columns
    ]

)

display(missing_values_df)

# COMMAND ----------

# ============================================================================
# STEP 4 : Check Duplicate Records
#
# Why?
# ----
# Duplicate records can occur due to repeated ingestion or source system
# issues.
#
# Before building the Silver layer, we verify that every record is unique.
#
# If duplicates exist, we would investigate and remove them before loading
# into Silver.
# ============================================================================

# Count total rows
total_rows = bronze_order_payments_df.count()

# Count unique rows
distinct_rows = bronze_order_payments_df.distinct().count()

# Calculate duplicate rows
duplicate_rows = total_rows - distinct_rows

print(f"Total Rows      : {total_rows}")
print(f"Distinct Rows   : {distinct_rows}")
print(f"Duplicate Rows  : {duplicate_rows}")

# COMMAND ----------

# ============================================================================
# STEP 5 : Create Business Validation Flags
#
# Why?
# ----
# The Silver layer enriches the raw data by adding business-quality flags.
#
# These flags make it easier for analysts and downstream pipelines to
# identify suspicious or interesting records without repeatedly writing
# complex validation logic.
#
# Flags Created:
# 1. invalid_payment_value_flag
# 2. invalid_installments_flag
# 3. multiple_payment_flag
# ============================================================================

from pyspark.sql.functions import when, col, count
from pyspark.sql.window import Window

# Count how many payment records exist for each order
payment_window = Window.partitionBy("order_id")

silver_order_payments_df = (

    bronze_order_payments_df

    # Payment value should always be greater than zero
    .withColumn(
        "invalid_payment_value_flag",
        when(col("payment_value") <= 0, True).otherwise(False)
    )

    # Installments should be at least 1
    .withColumn(
        "invalid_installments_flag",
        when(col("payment_installments") < 1, True).otherwise(False)
    )

    # Flag orders having multiple payment records
    .withColumn(
        "multiple_payment_flag",
        when(count("*").over(payment_window) > 1, True).otherwise(False)
    )

)

display(silver_order_payments_df)

# COMMAND ----------

# ============================================================================
# STEP 6 : Validate Payment Value Flag
#
# Why?
# ----
# Payment values should always be greater than zero.
#
# This validation shows how many records have:
# • Valid payment values
# • Invalid payment values
#
# Ideally, almost all records should have valid payment values.
# ============================================================================

from pyspark.sql.functions import count

(
    silver_order_payments_df
    .groupBy("invalid_payment_value_flag")
    .agg(count("*").alias("record_count"))
    .orderBy("invalid_payment_value_flag")
).show()

# COMMAND ----------

# ============================================================================
# STEP 7 : Validate Installment Flag
#
# Why?
# ----
# Installments should always be at least 1.
#
# This validation tells us whether any orders have invalid installment counts.
# ============================================================================

(
    silver_order_payments_df
    .groupBy("invalid_installments_flag")
    .agg(count("*").alias("record_count"))
    .orderBy("invalid_installments_flag")
).show()

# COMMAND ----------

# ============================================================================
# STEP 8 : Validate Multiple Payment Flag
#
# Why?
# ----
# Some orders are paid using multiple payment methods.
#
# This is not an error.
#
# We simply flag such orders because analysts may want to study payment
# behavior later.
# ============================================================================

(
    silver_order_payments_df
    .groupBy("multiple_payment_flag")
    .agg(count("*").alias("record_count"))
    .orderBy("multiple_payment_flag")
).show()

# COMMAND ----------

# ============================================================================
# STEP 9 : Create Silver Schema
#
# Why?
# ----
# The Silver schema stores cleaned and enriched datasets.
#
# If the schema already exists, this command does nothing.
# ============================================================================

spark.sql("""

CREATE SCHEMA IF NOT EXISTS workspace.silver

""")

print("✅ Silver schema created successfully.")

# COMMAND ----------

# ============================================================================
# STEP 10 : Create Silver Order Payments Delta Table
#
# Why?
# ----
# The Silver table stores the cleaned and enriched payment data.
#
# Compared to Bronze, this table contains additional business validation
# flags that make downstream analytics much easier.
#
# New Columns Added:
# • invalid_payment_value_flag
# • invalid_installments_flag
# • multiple_payment_flag
# ============================================================================

spark.sql("""

CREATE TABLE IF NOT EXISTS workspace.silver.order_payments
(

    order_id STRING,
    payment_sequential INT,
    payment_type STRING,
    payment_installments INT,
    payment_value DOUBLE,

    invalid_payment_value_flag BOOLEAN,
    invalid_installments_flag BOOLEAN,
    multiple_payment_flag BOOLEAN

)

USING DELTA

""")

print("✅ Silver Order Payments Delta table created successfully.")

# COMMAND ----------

# ============================================================================
# STEP 11 : Load Data into the Silver Delta Table
#
# Why?
# ----
# After applying all business validations, we now save the enriched dataset
# into the Silver Delta table.
#
# The overwrite mode replaces the existing data while keeping the table
# structure intact.
#
# This ensures that every pipeline execution produces the latest Silver
# version of the dataset.
# ============================================================================

silver_order_payments_df.write \
    .mode("overwrite") \
    .insertInto("workspace.silver.order_payments")

print("✅ Order Payments data successfully loaded into the Silver Delta table.")

# COMMAND ----------

# ============================================================================
# STEP 12 : Read the Silver Delta Table
#
# Why?
# ----
# Read the Silver table back from Unity Catalog to verify that the data
# has been successfully written.
#
# This also confirms that downstream notebooks can access the table.
# ============================================================================

silver_order_payments_df = spark.table("workspace.silver.order_payments")

display(silver_order_payments_df)

# COMMAND ----------

# ============================================================================
# STEP 13 : Validate Record Count
#
# Why?
# ----
# The Silver table should contain the same number of records as the Bronze
# table because we only added validation flags and did not remove any rows.
#
# If the counts differ, it indicates a problem during the transformation
# or loading process.
# ============================================================================

# Count Bronze records
bronze_count = bronze_order_payments_df.count()

# Count Silver records
silver_count = silver_order_payments_df.count()

print(f"Bronze Records : {bronze_count}")
print(f"Silver Records : {silver_count}")

if bronze_count == silver_count:
    print("✅ Validation Passed: Row counts match.")
else:
    print("❌ Validation Failed: Row counts do not match.")

# COMMAND ----------

# MAGIC %sql
# MAGIC
# MAGIC DESCRIBE HISTORY workspace.silver.order_payments;

# COMMAND ----------

# ============================================================================
# STEP 16 : Export Silver Order Payments Delta Table to AWS S3
#
# Why?
# ----
# Exporting the Silver Delta table creates a physical copy in the data lake.
#
# This allows:
# • Other tools to read the data
# • Future pipelines to use the Delta files directly
# • Backup and portability
# ============================================================================

silver_order_payments_df.write \
    .format("delta") \
    .mode("overwrite") \
    .save("s3://omnicapstone/silver_tables/order_payments")

print("✅ Silver Order Payments Delta table exported to S3 successfully.")

# COMMAND ----------

# MAGIC %md
# MAGIC # Order Payments Pipeline Documentation (Ingestion → Bronze → Silver)
# MAGIC
# MAGIC ---
# MAGIC
# MAGIC # Project Overview
# MAGIC
# MAGIC The **Order Payments** dataset contains information about how customers paid for their orders in the Olist e-commerce platform.
# MAGIC
# MAGIC This dataset captures payment-related details such as:
# MAGIC
# MAGIC - Order ID
# MAGIC - Payment Sequence
# MAGIC - Payment Method
# MAGIC - Number of Installments
# MAGIC - Payment Amount
# MAGIC
# MAGIC Unlike the Orders dataset, this table focuses entirely on **payment transactions**, making it useful for payment analytics, fraud detection, installment analysis, and customer payment behavior.
# MAGIC
# MAGIC The objective of this pipeline is to ingest the raw payment data, store it in the Bronze layer, enrich it with business validations in the Silver layer, and finally export the Delta tables back to AWS S3.
# MAGIC
# MAGIC ---
# MAGIC
# MAGIC # Dataset Schema
# MAGIC
# MAGIC | Column | Datatype | Description |
# MAGIC |----------|----------|-------------|
# MAGIC | order_id | STRING | Unique identifier of an order |
# MAGIC | payment_sequential | INT | Sequence number of the payment for an order |
# MAGIC | payment_type | STRING | Mode of payment (Credit Card, Voucher, Boleto, Debit Card etc.) |
# MAGIC | payment_installments | INT | Number of installments chosen by the customer |
# MAGIC | payment_value | DOUBLE | Amount paid in that payment transaction |
# MAGIC
# MAGIC ---
# MAGIC
# MAGIC # Medallion Architecture
# MAGIC
# MAGIC ```
# MAGIC                 AWS S3 (Raw CSV)
# MAGIC                        │
# MAGIC                        ▼
# MAGIC              01_Ingestion Notebook
# MAGIC                        │
# MAGIC                        ▼
# MAGIC               Bronze Delta Table
# MAGIC                        │
# MAGIC                        ▼
# MAGIC         Business Validation & Enrichment
# MAGIC                        │
# MAGIC                        ▼
# MAGIC               Silver Delta Table
# MAGIC                        │
# MAGIC                        ▼
# MAGIC         Export Delta Files back to AWS S3
# MAGIC ```
# MAGIC
# MAGIC ---
# MAGIC
# MAGIC # Phase 1 : Ingestion Layer
# MAGIC
# MAGIC Notebook:
# MAGIC
# MAGIC ```
# MAGIC 02_Read_Order_Payments
# MAGIC ```
# MAGIC
# MAGIC ---
# MAGIC
# MAGIC ## Objective
# MAGIC
# MAGIC Read the raw CSV file stored inside AWS S3 and understand the dataset before storing it inside the Medallion Architecture.
# MAGIC
# MAGIC ---
# MAGIC
# MAGIC ## Source File
# MAGIC
# MAGIC ```
# MAGIC s3://omnicapstone/raw_data/olist_order_payments_dataset.csv
# MAGIC ```
# MAGIC
# MAGIC ---
# MAGIC
# MAGIC ## Activities Performed
# MAGIC
# MAGIC ### 1. Loaded CSV into Spark DataFrame
# MAGIC
# MAGIC The CSV file was read using Spark.
# MAGIC
# MAGIC Options used:
# MAGIC
# MAGIC - Header = True
# MAGIC - Infer Schema = True
# MAGIC
# MAGIC This automatically identified the correct datatypes.
# MAGIC
# MAGIC ---
# MAGIC
# MAGIC ### 2. Display Dataset
# MAGIC
# MAGIC The first few rows were displayed to verify
# MAGIC
# MAGIC - column names
# MAGIC - datatypes
# MAGIC - sample values
# MAGIC
# MAGIC ---
# MAGIC
# MAGIC ### 3. Record Count Validation
# MAGIC
# MAGIC Purpose:
# MAGIC
# MAGIC To ensure the source file was completely loaded.
# MAGIC
# MAGIC Result
# MAGIC
# MAGIC ```
# MAGIC Total Records = 103886
# MAGIC ```
# MAGIC
# MAGIC ---
# MAGIC
# MAGIC ### 4. Schema Validation
# MAGIC
# MAGIC Purpose:
# MAGIC
# MAGIC Verify every column has the expected datatype.
# MAGIC
# MAGIC Schema
# MAGIC
# MAGIC ```
# MAGIC order_id                STRING
# MAGIC payment_sequential      INTEGER
# MAGIC payment_type            STRING
# MAGIC payment_installments    INTEGER
# MAGIC payment_value           DOUBLE
# MAGIC ```
# MAGIC
# MAGIC ---
# MAGIC
# MAGIC ### 5. Missing Value Analysis
# MAGIC
# MAGIC Each column was checked for NULL values.
# MAGIC
# MAGIC Result
# MAGIC
# MAGIC | Column | Missing Values |
# MAGIC |----------|---------------|
# MAGIC | order_id | 0 |
# MAGIC | payment_sequential | 0 |
# MAGIC | payment_type | 0 |
# MAGIC | payment_installments | 0 |
# MAGIC | payment_value | 0 |
# MAGIC
# MAGIC Observation
# MAGIC
# MAGIC The dataset is completely clean.
# MAGIC
# MAGIC No NULL values were found.
# MAGIC
# MAGIC ---
# MAGIC
# MAGIC ### 6. Duplicate Record Check
# MAGIC
# MAGIC Purpose
# MAGIC
# MAGIC To ensure no duplicate rows exist before loading into Bronze.
# MAGIC
# MAGIC Result
# MAGIC
# MAGIC ```
# MAGIC Total Rows      = 103886
# MAGIC Distinct Rows   = 103886
# MAGIC Duplicate Rows  = 0
# MAGIC ```
# MAGIC
# MAGIC Observation
# MAGIC
# MAGIC No duplicate records exist.
# MAGIC
# MAGIC ---
# MAGIC
# MAGIC # Bronze Layer
# MAGIC
# MAGIC Notebook
# MAGIC
# MAGIC ```
# MAGIC 02_Create_Bronze_Order_Payments
# MAGIC ```
# MAGIC
# MAGIC ---
# MAGIC
# MAGIC ## Objective
# MAGIC
# MAGIC Store the raw payment dataset exactly as received.
# MAGIC
# MAGIC No transformations are performed in Bronze.
# MAGIC
# MAGIC The Bronze layer acts as the permanent raw copy.
# MAGIC
# MAGIC ---
# MAGIC
# MAGIC ## Activities Performed
# MAGIC
# MAGIC ### Step 1
# MAGIC
# MAGIC Read the raw CSV again.
# MAGIC
# MAGIC ---
# MAGIC
# MAGIC ### Step 2
# MAGIC
# MAGIC Created Bronze Schema
# MAGIC
# MAGIC ```
# MAGIC workspace.bronze
# MAGIC ```
# MAGIC
# MAGIC Purpose
# MAGIC
# MAGIC To organize all raw datasets separately from cleaned datasets.
# MAGIC
# MAGIC ---
# MAGIC
# MAGIC ### Step 3
# MAGIC
# MAGIC Created Bronze Delta Table
# MAGIC
# MAGIC ```
# MAGIC workspace.bronze.order_payments
# MAGIC ```
# MAGIC
# MAGIC Schema
# MAGIC
# MAGIC ```
# MAGIC order_id
# MAGIC payment_sequential
# MAGIC payment_type
# MAGIC payment_installments
# MAGIC payment_value
# MAGIC ```
# MAGIC
# MAGIC ---
# MAGIC
# MAGIC ### Step 4
# MAGIC
# MAGIC Loaded the DataFrame into Bronze.
# MAGIC
# MAGIC Write Mode
# MAGIC
# MAGIC ```
# MAGIC Overwrite
# MAGIC ```
# MAGIC
# MAGIC ---
# MAGIC
# MAGIC ### Step 5
# MAGIC
# MAGIC Validated Record Count
# MAGIC
# MAGIC ```
# MAGIC Source Records = 103886
# MAGIC
# MAGIC Bronze Records = 103886
# MAGIC ```
# MAGIC
# MAGIC Validation
# MAGIC
# MAGIC Passed
# MAGIC
# MAGIC ---
# MAGIC
# MAGIC ### Step 6
# MAGIC
# MAGIC Viewed Delta History
# MAGIC
# MAGIC Purpose
# MAGIC
# MAGIC Verify
# MAGIC
# MAGIC - CREATE TABLE operation
# MAGIC - WRITE operation
# MAGIC
# MAGIC This confirms Delta Lake successfully tracked every transaction.
# MAGIC
# MAGIC ---
# MAGIC
# MAGIC ### Step 7
# MAGIC
# MAGIC Verified Table Exists
# MAGIC
# MAGIC ```
# MAGIC SHOW TABLES IN workspace.bronze
# MAGIC ```
# MAGIC
# MAGIC Verified
# MAGIC
# MAGIC ```
# MAGIC workspace.bronze.order_payments
# MAGIC ```
# MAGIC
# MAGIC ---
# MAGIC
# MAGIC ### Step 8
# MAGIC
# MAGIC Exported Bronze Delta Files
# MAGIC
# MAGIC Destination
# MAGIC
# MAGIC ```
# MAGIC s3://omnicapstone/bronze_tables/order_payments
# MAGIC ```
# MAGIC
# MAGIC Purpose
# MAGIC
# MAGIC Maintain a physical Delta copy inside AWS S3.
# MAGIC
# MAGIC ---
# MAGIC
# MAGIC # Silver Layer
# MAGIC
# MAGIC Notebook
# MAGIC
# MAGIC ```
# MAGIC 02_Create_Silver_Order_Payments
# MAGIC ```
# MAGIC
# MAGIC ---
# MAGIC
# MAGIC # Objective
# MAGIC
# MAGIC The Silver layer improves data quality.
# MAGIC
# MAGIC Instead of simply copying the Bronze table, we enrich it with business validation flags.
# MAGIC
# MAGIC This makes downstream analytics much easier.
# MAGIC
# MAGIC ---
# MAGIC
# MAGIC ## Step 1
# MAGIC
# MAGIC Read Bronze Table
# MAGIC
# MAGIC ```
# MAGIC workspace.bronze.order_payments
# MAGIC ```
# MAGIC
# MAGIC ---
# MAGIC
# MAGIC ## Step 2
# MAGIC
# MAGIC Profile Dataset
# MAGIC
# MAGIC Verified
# MAGIC
# MAGIC - Record Count
# MAGIC - Column Count
# MAGIC - Schema
# MAGIC
# MAGIC ---
# MAGIC
# MAGIC ## Step 3
# MAGIC
# MAGIC Missing Value Analysis
# MAGIC
# MAGIC Result
# MAGIC
# MAGIC No NULL values.
# MAGIC
# MAGIC ---
# MAGIC
# MAGIC ## Step 4
# MAGIC
# MAGIC Duplicate Check
# MAGIC
# MAGIC Result
# MAGIC
# MAGIC No duplicate records.
# MAGIC
# MAGIC ---
# MAGIC
# MAGIC # Business Enrichment
# MAGIC
# MAGIC Unlike Bronze, the Silver layer introduces new columns.
# MAGIC
# MAGIC These columns provide business-level information without deleting any records.
# MAGIC
# MAGIC ---
# MAGIC
# MAGIC # Column 1
# MAGIC
# MAGIC ```
# MAGIC invalid_payment_value_flag
# MAGIC ```
# MAGIC
# MAGIC Purpose
# MAGIC
# MAGIC Payment amount should always be greater than zero.
# MAGIC
# MAGIC Logic
# MAGIC
# MAGIC ```
# MAGIC payment_value <= 0
# MAGIC ```
# MAGIC
# MAGIC Then
# MAGIC
# MAGIC ```
# MAGIC True
# MAGIC ```
# MAGIC
# MAGIC Else
# MAGIC
# MAGIC ```
# MAGIC False
# MAGIC ```
# MAGIC
# MAGIC Reason
# MAGIC
# MAGIC Negative or zero payment amounts usually indicate
# MAGIC
# MAGIC - source system issues
# MAGIC - cancelled transactions
# MAGIC - refunds
# MAGIC - invalid records
# MAGIC
# MAGIC Result
# MAGIC
# MAGIC ```
# MAGIC False = 103877
# MAGIC
# MAGIC True = 9
# MAGIC ```
# MAGIC
# MAGIC Meaning
# MAGIC
# MAGIC Only nine records have suspicious payment values.
# MAGIC
# MAGIC ---
# MAGIC
# MAGIC # Column 2
# MAGIC
# MAGIC ```
# MAGIC invalid_installments_flag
# MAGIC ```
# MAGIC
# MAGIC Purpose
# MAGIC
# MAGIC Customers should choose at least one installment.
# MAGIC
# MAGIC Logic
# MAGIC
# MAGIC ```
# MAGIC payment_installments < 1
# MAGIC ```
# MAGIC
# MAGIC Then
# MAGIC
# MAGIC ```
# MAGIC True
# MAGIC ```
# MAGIC
# MAGIC Else
# MAGIC
# MAGIC ```
# MAGIC False
# MAGIC ```
# MAGIC
# MAGIC Reason
# MAGIC
# MAGIC Zero or negative installments are not valid business values.
# MAGIC
# MAGIC Result
# MAGIC
# MAGIC ```
# MAGIC False = 103884
# MAGIC
# MAGIC True = 2
# MAGIC ```
# MAGIC
# MAGIC Meaning
# MAGIC
# MAGIC Only two records have invalid installment counts.
# MAGIC
# MAGIC ---
# MAGIC
# MAGIC # Column 3
# MAGIC
# MAGIC ```
# MAGIC multiple_payment_flag
# MAGIC ```
# MAGIC
# MAGIC Purpose
# MAGIC
# MAGIC Identify orders paid using multiple payment records.
# MAGIC
# MAGIC Logic
# MAGIC
# MAGIC A Window Function counts payment records for every order.
# MAGIC
# MAGIC ```
# MAGIC Window.partitionBy(order_id)
# MAGIC ```
# MAGIC
# MAGIC If
# MAGIC
# MAGIC ```
# MAGIC Count > 1
# MAGIC ```
# MAGIC
# MAGIC Then
# MAGIC
# MAGIC ```
# MAGIC True
# MAGIC ```
# MAGIC
# MAGIC Else
# MAGIC
# MAGIC ```
# MAGIC False
# MAGIC ```
# MAGIC
# MAGIC Reason
# MAGIC
# MAGIC Some customers split payments across
# MAGIC
# MAGIC - Credit Card
# MAGIC - Voucher
# MAGIC - Boleto
# MAGIC - Multiple Credit Cards
# MAGIC
# MAGIC This is NOT an error.
# MAGIC
# MAGIC Instead, it provides valuable business insight.
# MAGIC
# MAGIC Result
# MAGIC
# MAGIC ```
# MAGIC False = 96479
# MAGIC
# MAGIC True = 7407
# MAGIC ```
# MAGIC
# MAGIC Meaning
# MAGIC
# MAGIC 7407 payment records belong to orders that used multiple payments.
# MAGIC
# MAGIC ---
# MAGIC
# MAGIC # Why Use Window Function?
# MAGIC
# MAGIC Instead of grouping the table and losing rows, a Window Function calculates the number of payment records **while keeping every row intact**.
# MAGIC
# MAGIC Example
# MAGIC
# MAGIC | Order | Payment |
# MAGIC |--------|----------|
# MAGIC | A | Credit Card |
# MAGIC | A | Voucher |
# MAGIC | B | Boleto |
# MAGIC
# MAGIC Output
# MAGIC
# MAGIC | Order | Multiple Payment |
# MAGIC |--------|------------------|
# MAGIC | A | True |
# MAGIC | A | True |
# MAGIC | B | False |
# MAGIC
# MAGIC This preserves all payment records while still identifying multi-payment orders.
# MAGIC
# MAGIC ---
# MAGIC
# MAGIC # Silver Table Schema
# MAGIC
# MAGIC ```
# MAGIC order_id
# MAGIC payment_sequential
# MAGIC payment_type
# MAGIC payment_installments
# MAGIC payment_value
# MAGIC
# MAGIC invalid_payment_value_flag
# MAGIC invalid_installments_flag
# MAGIC multiple_payment_flag
# MAGIC ```
# MAGIC
# MAGIC ---
# MAGIC
# MAGIC # Silver Table Validation
# MAGIC
# MAGIC Bronze Records
# MAGIC
# MAGIC ```
# MAGIC 103886
# MAGIC ```
# MAGIC
# MAGIC Silver Records
# MAGIC
# MAGIC ```
# MAGIC 103886
# MAGIC ```
# MAGIC
# MAGIC Validation
# MAGIC
# MAGIC Passed
# MAGIC
# MAGIC No records were lost during transformation.
# MAGIC
# MAGIC ---
# MAGIC
# MAGIC # Delta History
# MAGIC
# MAGIC Verified
# MAGIC
# MAGIC - CREATE TABLE
# MAGIC - WRITE
# MAGIC
# MAGIC Purpose
# MAGIC
# MAGIC Track every modification made to the Silver table.
# MAGIC
# MAGIC ---
# MAGIC
# MAGIC # Silver Export
# MAGIC
# MAGIC Export Destination
# MAGIC
# MAGIC ```
# MAGIC s3://omnicapstone/silver_tables/order_payments
# MAGIC ```
# MAGIC
# MAGIC Purpose
# MAGIC
# MAGIC Maintain a physical Delta copy of the enriched Silver dataset inside AWS S3.
# MAGIC
# MAGIC ---
# MAGIC
# MAGIC # Final Pipeline
# MAGIC
# MAGIC ```
# MAGIC AWS S3 (CSV)
# MAGIC         │
# MAGIC         ▼
# MAGIC Read Order Payments Notebook
# MAGIC         │
# MAGIC         ▼
# MAGIC Dataset Profiling
# MAGIC         │
# MAGIC         ▼
# MAGIC NULL Check
# MAGIC         │
# MAGIC         ▼
# MAGIC Duplicate Check
# MAGIC         │
# MAGIC         ▼
# MAGIC Bronze Delta Table
# MAGIC         │
# MAGIC         ▼
# MAGIC Read Bronze Table
# MAGIC         │
# MAGIC         ▼
# MAGIC Business Validation
# MAGIC         │
# MAGIC         ├──────── invalid_payment_value_flag
# MAGIC         │
# MAGIC         ├──────── invalid_installments_flag
# MAGIC         │
# MAGIC         └──────── multiple_payment_flag
# MAGIC         │
# MAGIC         ▼
# MAGIC Silver Delta Table
# MAGIC         │
# MAGIC         ▼
# MAGIC Validate Record Count
# MAGIC         │
# MAGIC         ▼
# MAGIC Delta History
# MAGIC         │
# MAGIC         ▼
# MAGIC Export Delta Files to AWS S3
# MAGIC ```
# MAGIC
# MAGIC ---
# MAGIC
# MAGIC # Key Learning Outcomes
# MAGIC
# MAGIC - Read raw CSV files from AWS S3 using Spark.
# MAGIC - Perform dataset profiling before ingestion.
# MAGIC - Validate record counts, schema, NULL values, and duplicates.
# MAGIC - Build Bronze Delta tables without modifying the source data.
# MAGIC - Enrich data in the Silver layer using business validation rules.
# MAGIC - Use Window Functions to identify orders with multiple payment records while preserving row-level granularity.
# MAGIC - Validate transformed data before loading it into Delta tables.
# MAGIC - Export Bronze and Silver Delta tables back to AWS S3 for downstream consumption.
# MAGIC - Follow the Medallion Architecture (Ingestion → Bronze → Silver) to build a reliable, maintainable, and production-ready data engineering pipeline.

# COMMAND ----------

