# Databricks notebook source
# MAGIC %md
# MAGIC # Silver Layer - Orders Pipeline
# MAGIC
# MAGIC ## Objective
# MAGIC
# MAGIC The purpose of the Silver layer is to transform the raw Bronze data into a clean, standardized, and trusted dataset.
# MAGIC
# MAGIC Unlike the Bronze layer, the Silver layer performs data quality validation, business rule validation, and data standardization while preserving legitimate business information.
# MAGIC
# MAGIC ### Input
# MAGIC
# MAGIC workspace.bronze.orders
# MAGIC
# MAGIC ### Output
# MAGIC
# MAGIC workspace.silver.orders
# MAGIC
# MAGIC ### Responsibilities
# MAGIC
# MAGIC - Read data from the Bronze layer
# MAGIC - Assess data quality
# MAGIC - Apply business validation rules
# MAGIC - Handle invalid records
# MAGIC - Standardize the dataset
# MAGIC - Store the cleaned data in the Silver layer

# COMMAND ----------

# ============================================================================
# STEP 1 : Read the Bronze Orders Delta Table
# ============================================================================
#
# Objective
# ---------
# Read the Orders dataset from the Bronze Delta table.
#
# Why?
# ----
# The Silver layer should always use the Bronze layer as its
# source of truth rather than reading the original CSV again.
#
# This creates a proper Medallion Architecture:
#
# S3 CSV
#     │
#     ▼
# Bronze Delta
#     │
#     ▼
# Silver Delta
#
# Output
# ------
# bronze_orders_df : PySpark DataFrame
#
# ============================================================================

bronze_orders_df = spark.table("workspace.bronze.orders")

# COMMAND ----------

# MAGIC %md
# MAGIC # STEP 2
# MAGIC
# MAGIC ## Perform Data Quality Assessment
# MAGIC
# MAGIC Before applying any transformations, we first assess the quality of the Bronze data.
# MAGIC
# MAGIC The goal is to identify issues such as:
# MAGIC
# MAGIC - Missing values
# MAGIC - Duplicate records
# MAGIC - Invalid business values
# MAGIC - Data type inconsistencies
# MAGIC
# MAGIC Only after understanding the data quality should cleaning rules be applied.
# MAGIC
# MAGIC This ensures that every transformation performed in the Silver layer has a valid business justification.

# COMMAND ----------

# ============================================================================
# STEP 2 : Data Quality Assessment
# ============================================================================
#
# Objective
# ---------
# Perform an initial assessment of the Bronze dataset before applying
# any cleaning or transformations.
#
# Why?
# ----
# Every transformation in the Silver layer should be based on an
# observed data quality issue rather than assumptions.
#
# The assessment includes:
# • Total records
# • Number of columns
# • Schema validation
#
# ============================================================================

# Count the total number of records
total_records = bronze_orders_df.count()

# Count the total number of columns
total_columns = len(bronze_orders_df.columns)

print(f"Total Records : {total_records}")
print(f"Total Columns : {total_columns}")

print("\nSchema Information")
bronze_orders_df.printSchema()

# COMMAND ----------

# MAGIC %md
# MAGIC # STEP 3
# MAGIC
# MAGIC ## Analyze Missing Values
# MAGIC
# MAGIC Before handling missing values, we identify which columns contain NULL values.
# MAGIC
# MAGIC It is important to understand that not every NULL value represents bad data.
# MAGIC
# MAGIC Some NULL values are expected as part of the business process.
# MAGIC
# MAGIC For example:
# MAGIC
# MAGIC - An order that has not yet been approved will not have an approval timestamp.
# MAGIC - A cancelled order will not have delivery timestamps.
# MAGIC
# MAGIC Therefore, every NULL value must be evaluated based on business logic before deciding whether to keep or remove it.

# COMMAND ----------

# ============================================================================
# STEP 3 : Analyze Missing Values
# ============================================================================
#
# Objective
# ---------
# Count the number of NULL values present in each column.
#
# Why?
# ----
# Missing values are one of the most common data quality issues.
#
# However, not every NULL represents bad data.
#
# Some NULL values are expected due to business processes,
# while others may indicate incomplete or incorrect records.
#
# This analysis helps determine which columns require cleaning
# in the Silver layer.
#
# ============================================================================

from pyspark.sql.functions import col, when, count

# Count NULL values in every column
missing_values_df = bronze_orders_df.select(

    [
        count(
            when(col(column).isNull(), column)
        ).alias(column)

        for column in bronze_orders_df.columns
    ]

)

display(missing_values_df)

# COMMAND ----------

# MAGIC %md
# MAGIC # STEP 4
# MAGIC
# MAGIC ## Investigate Missing Values
# MAGIC
# MAGIC Finding NULL values is only the first step.
# MAGIC
# MAGIC Before removing or replacing any data, we investigate whether those NULL values are expected based on the business process.
# MAGIC
# MAGIC For example:
# MAGIC
# MAGIC - A cancelled order may never have a delivery date.
# MAGIC - An unavailable order may never be shipped.
# MAGIC - A delivered order should normally have all delivery timestamps.
# MAGIC
# MAGIC This investigation helps us distinguish between valid business scenarios and actual data quality issues.

# COMMAND ----------

# ============================================================================
# STEP 4 : Investigate Missing Approval Dates
# ============================================================================
#
# Objective
# ---------
# Identify which order statuses have missing approval timestamps.
#
# Why?
# ----
# Instead of assuming missing values are incorrect, we verify
# whether they are expected based on the business process.
#
# If NULL approval dates belong only to cancelled or unavailable
# orders, then those NULL values are legitimate and should not
# be removed.
#
# ============================================================================

from pyspark.sql.functions import col

display(

    bronze_orders_df
        .filter(col("order_approved_at").isNull())
        .groupBy("order_status")
        .count()

)

# COMMAND ----------

# ============================================================================
# STEP 4.1 : Investigate Delivered Orders Missing Approval Timestamp
# ============================================================================
#
# Objective
# ---------
# Inspect delivered orders that have a NULL approval timestamp.
#
# Why?
# ----
# Delivered orders are expected to have been approved before shipment.
#
# These records are investigated to determine whether they represent
# valid business scenarios or potential data quality issues.
#
# ============================================================================

display(

    bronze_orders_df
        .filter(
            (col("order_status") == "delivered") &
            (col("order_approved_at").isNull())
        )

)

# COMMAND ----------

# ============================================================================
# STEP 5 : Create Data Quality Flag
# ============================================================================
#
# Objective
# ---------
# Add a flag to identify delivered orders that are missing the
# approval timestamp.
#
# Why?
# ----
# These records represent data quality issues rather than valid
# business events.
#
# Instead of deleting them, we preserve the data and flag the
# inconsistent records for downstream consumers.
#
# ============================================================================

from pyspark.sql.functions import when, col

silver_orders_df = bronze_orders_df.withColumn(

    "approval_missing_flag",

    when(
        (col("order_status") == "delivered") &
        (col("order_approved_at").isNull()),
        True
    ).otherwise(False)

)

display(silver_orders_df)

# COMMAND ----------

# ============================================================================
# STEP 6 : Validate the Data Quality Flag
# ============================================================================
#
# Objective
# ---------
# Count how many records have been marked as data quality issues.
#
# Expected Result
# ---------------
# approval_missing_flag = true  -> 14 records
# approval_missing_flag = false -> 99,427 records
#
# This confirms that our transformation worked correctly.
# ============================================================================

from pyspark.sql.functions import count

(
    silver_orders_df
    .groupBy("approval_missing_flag")
    .agg(count("*").alias("record_count"))
    .orderBy("approval_missing_flag")
).show()

# COMMAND ----------

# ============================================================================
# STEP 7 : Check Duplicate Business Keys
# ============================================================================
#
# Objective
# ---------
# Verify that every order_id appears only once.
#
# Why?
# ----
# order_id is the primary business key for the Orders table.
#
# Duplicate order_ids would indicate data corruption or duplicate ingestion.
#
# Expected Result:
# ----------------
# No duplicate order_ids should exist.
# ============================================================================

from pyspark.sql.functions import count

duplicate_orders = (
    silver_orders_df
    .groupBy("order_id")
    .agg(count("*").alias("record_count"))
    .filter(col("record_count") > 1)
)

duplicate_count = duplicate_orders.count()

print(f"Duplicate Order IDs Found : {duplicate_count}")

# COMMAND ----------

# ============================================================================
# STEP 8 : Validate Order Lifecycle Timeline
# ============================================================================
#
# Objective
# ---------
# Find records where the order timeline is logically incorrect.
#
# Expected Timeline
# -----------------
# Purchase
#      ↓
# Approval
#      ↓
# Carrier Pickup
#      ↓
# Customer Delivery
#
# Any violation of this sequence is considered a data quality issue.
# ============================================================================

from pyspark.sql.functions import col

invalid_timeline_df = (
    silver_orders_df
    .filter(
        (col("order_approved_at").isNotNull()) &
        (col("order_delivered_carrier_date").isNotNull()) &
        (col("order_delivered_customer_date").isNotNull()) &
        (
            (col("order_approved_at") < col("order_purchase_timestamp")) |
            (col("order_delivered_carrier_date") < col("order_approved_at")) |
            (col("order_delivered_customer_date") < col("order_delivered_carrier_date"))
        )
    )
)

print(f"Invalid Timeline Records : {invalid_timeline_df.count()}")

# COMMAND ----------

# ============================================================================
# STEP 9 : Identify Which Timeline Rule Is Failing
# ============================================================================
#
# Objective
# ---------
# Create separate flags for each business rule violation.
#
# This helps us understand WHY a record failed instead of just
# knowing that it failed.
#
# ============================================================================

from pyspark.sql.functions import when, col

timeline_analysis_df = (
    silver_orders_df

    # Rule 1
    .withColumn(
        "approval_before_purchase",
        when(
            col("order_approved_at") < col("order_purchase_timestamp"),
            True
        ).otherwise(False)
    )

    # Rule 2
    .withColumn(
        "carrier_before_approval",
        when(
            col("order_delivered_carrier_date") < col("order_approved_at"),
            True
        ).otherwise(False)
    )

    # Rule 3
    .withColumn(
        "delivery_before_carrier",
        when(
            col("order_delivered_customer_date") < col("order_delivered_carrier_date"),
            True
        ).otherwise(False)
    )
)

display(timeline_analysis_df)

# COMMAND ----------

# ============================================================================
# Count violations for each business rule
# ============================================================================

from pyspark.sql.functions import sum

timeline_analysis_df.select(

    sum(col("approval_before_purchase").cast("int")).alias("Approval Before Purchase"),

    sum(col("carrier_before_approval").cast("int")).alias("Carrier Before Approval"),

    sum(col("delivery_before_carrier").cast("int")).alias("Delivery Before Carrier")

).show()

# COMMAND ----------

# ============================================================================
# STEP 10 : Create Timeline Quality Flag
# ============================================================================
#
# Objective
# ---------
# Flag orders whose business timeline is logically inconsistent.
#
# We DO NOT remove these records.
#
# Instead, we mark them so downstream users can decide
# whether to include or exclude them.
#
# ============================================================================

from pyspark.sql.functions import when, col

silver_orders_df = silver_orders_df.withColumn(

    "timeline_issue_flag",

    when(

        (
            (col("order_approved_at").isNotNull()) &
            (col("order_delivered_carrier_date").isNotNull()) &
            (col("order_delivered_customer_date").isNotNull()) &
            (
                (col("order_approved_at") < col("order_purchase_timestamp")) |
                (col("order_delivered_carrier_date") < col("order_approved_at")) |
                (col("order_delivered_customer_date") < col("order_delivered_carrier_date"))
            )

        ),

        True

    ).otherwise(False)

)

display(silver_orders_df)

# COMMAND ----------

#Validating the same
from pyspark.sql.functions import count

(
    silver_orders_df
    .groupBy("timeline_issue_flag")
    .agg(count("*").alias("record_count"))
    .show()
)

# COMMAND ----------

# ============================================================================
# STEP 11 : Create Silver Schema
# ============================================================================
#
# Objective
# ---------
# Create the Silver schema if it does not already exist.
#
# Silver stores cleaned and validated datasets.
# ============================================================================

spark.sql("""

CREATE SCHEMA IF NOT EXISTS workspace.silver

""")

print("✅ Silver schema created successfully.")

# COMMAND ----------

# ============================================================================
# STEP 12 : Create Silver Orders Delta Table
# ============================================================================
#
# Objective
# ---------
# Create an empty Delta table that will store the cleaned Orders data.
#
# Why?
# ----
# The Silver layer contains validated, cleaned, and business-ready data.
#
# This table will be populated in the next step.
#
# ============================================================================

spark.sql("""

CREATE TABLE IF NOT EXISTS workspace.silver.orders (

    order_id STRING,
    customer_id STRING,
    order_status STRING,
    order_purchase_timestamp TIMESTAMP,
    order_approved_at TIMESTAMP,
    order_delivered_carrier_date TIMESTAMP,
    order_delivered_customer_date TIMESTAMP,
    order_estimated_delivery_date TIMESTAMP,

    approval_missing_flag BOOLEAN,
    timeline_issue_flag BOOLEAN

)

USING DELTA

""")

print("✅ Silver Orders Delta table created successfully.")

# COMMAND ----------

# ============================================================================
# STEP 13 : Load Cleaned Orders Data into Silver
# ============================================================================
#
# Objective
# ---------
# Store the cleaned Orders dataframe into the Silver Delta table.
#
# Why overwrite?
# --------------
# During development we recreate the Silver table every run.
#
# In production this would usually be replaced with:
#   - MERGE
#   - Incremental Load
#   - Streaming
#
# ============================================================================

silver_orders_df.write \
    .mode("overwrite") \
    .insertInto("workspace.silver.orders")

print("✅ Orders data successfully loaded into the Silver Delta table.")

# COMMAND ----------

# ============================================================================
# STEP 14 : Validate Silver Orders Table
# ============================================================================
#
# Objective
# ---------
# Read the Silver Delta table back from Unity Catalog and verify:
#   1. Record Count
#   2. Number of Columns
#   3. Schema
#
# This confirms that the data was written correctly.
#
# ============================================================================
# there are 10 columns because:
#     because we added

# approval_missing_flag
# timeline_issue_flag

silver_table_df = spark.table("workspace.silver.orders")

print(f"Total Records : {silver_table_df.count()}")
print(f"Total Columns : {len(silver_table_df.columns)}")

print("\nSchema Information")
silver_table_df.printSchema()

# COMMAND ----------

#Displaying the final server table
# ============================================================================
# STEP 15 : Display Silver Orders Table
# ============================================================================

display(silver_table_df)

# COMMAND ----------

# ============================================================================
# STEP 16 : Compare Bronze vs Silver
# ============================================================================

bronze_count = spark.table("workspace.bronze.orders").count()
silver_count = spark.table("workspace.silver.orders").count()

print(f"Bronze Records : {bronze_count}")
print(f"Silver Records : {silver_count}")

if bronze_count == silver_count:
    print("✅ Validation Passed: No records lost during Silver transformation.")
else:
    print("❌ Validation Failed: Record counts do not match.")

# COMMAND ----------

#Checking the Delta History

spark.sql("DESCRIBE HISTORY workspace.silver.orders")

# COMMAND ----------

# MAGIC %sql
# MAGIC
# MAGIC SHOW TABLES IN workspace.silver;

# COMMAND ----------

# ============================================================================
# Export Silver Orders Delta Table to AWS S3
#
# Why?
# ----
# Although the Silver table already exists in Unity Catalog,
# many organizations also keep the physical Delta files in
# cloud storage (AWS S3, ADLS, GCS).
#
# These Delta files can later be used by:
#   - Gold Layer pipelines
#   - Machine Learning
#   - Power BI / Tableau
#   - Other Databricks workspaces
# ============================================================================

silver_orders_df.write \
    .format("delta") \
    .mode("overwrite") \
    .save("s3://omnicapstone/silver_tables/orders")

print("✅ Silver Orders Delta files exported to S3 successfully.")

# COMMAND ----------

