# Databricks notebook source
# MAGIC %md
# MAGIC # Omnichannel Customer Analytics
# MAGIC
# MAGIC ## Project Configuration Notebook
# MAGIC
# MAGIC ### Purpose
# MAGIC
# MAGIC This notebook contains all the common project configurations used throughout the automated data pipeline.
# MAGIC
# MAGIC Instead of hardcoding paths, database names, schemas, and storage locations inside every notebook, all common configurations are maintained here.
# MAGIC
# MAGIC This provides:
# MAGIC
# MAGIC - Centralized configuration management
# MAGIC - Easy maintenance
# MAGIC - Better scalability
# MAGIC - Reduced code duplication
# MAGIC - Faster migration between environments (Development, Testing, Production)
# MAGIC
# MAGIC Every notebook in the automated pipeline will load these configurations before execution.

# COMMAND ----------

# ============================================================
# Project Configuration
# ============================================================

# Why?
# -----
# This notebook stores all the common configurations used
# across the automated pipeline.
#
# Instead of hardcoding paths in every notebook,
# we define them once and reuse them everywhere.
#
# This makes the project:
# • Easier to maintain
# • Easier to scale
# • Production ready
# ============================================================


# ============================================================
# AWS S3 Paths
# ============================================================

RAW_DATA_PATH = "s3://omnicapstone/raw_data"

BRONZE_DATA_PATH = "s3://omnicapstone/bronze_tables"

SILVER_DATA_PATH = "s3://omnicapstone/silver_tables"


# ============================================================
# Unity Catalog Configuration
# ============================================================

CATALOG_NAME = "workspace"

BRONZE_SCHEMA = "bronze"

SILVER_SCHEMA = "silver"


# ============================================================
# Display Configuration
# ============================================================

print("Project Configuration Loaded Successfully")

print(f"Raw Data Path      : {RAW_DATA_PATH}")
print(f"Bronze Data Path   : {BRONZE_DATA_PATH}")
print(f"Silver Data Path   : {SILVER_DATA_PATH}")

print(f"Catalog Name       : {CATALOG_NAME}")
print(f"Bronze Schema      : {BRONZE_SCHEMA}")
print(f"Silver Schema      : {SILVER_SCHEMA}")

# COMMAND ----------

