# Databricks notebook source
# MAGIC %md
# MAGIC # Omnichannel Customer Analytics
# MAGIC
# MAGIC # Generic Ingestion Pipeline
# MAGIC
# MAGIC ## Purpose
# MAGIC
# MAGIC This notebook is responsible for reading any incoming raw dataset from Amazon S3.
# MAGIC
# MAGIC Instead of creating separate ingestion notebooks for every dataset, this notebook uses configurable parameters to dynamically identify the source file and load it into Spark.
# MAGIC
# MAGIC This design provides:
# MAGIC
# MAGIC - Reusable ingestion logic
# MAGIC - Centralized configuration
# MAGIC - Easy maintenance
# MAGIC - Scalability for future datasets
# MAGIC - Compatibility with Databricks Workflows
# MAGIC
# MAGIC The output of this notebook is a validated Spark DataFrame that will be passed to the Bronze layer.

# COMMAND ----------

# MAGIC %run ../01_Config/00_Project_Config

# COMMAND ----------

# ==========================================================
# Dataset Configuration
# ==========================================================

# Why?
# -----
# These parameters uniquely identify which dataset the pipeline
# should process. During automation, Databricks Workflows will
# pass these values dynamically.

DATASET_NAME = "orders"

SOURCE_FILE = "olist_orders_dataset.csv"

BRONZE_TABLE = "orders"

SILVER_TABLE = "orders"

print("Dataset Parameters Loaded Successfully\n")

print(f"Dataset Name : {DATASET_NAME}")
print(f"Source File  : {SOURCE_FILE}")
print(f"Bronze Table : {BRONZE_TABLE}")
print(f"Silver Table : {SILVER_TABLE}")

# COMMAND ----------

# ==========================================================
# Build Source Dataset Path
# ==========================================================

# Why?
# -----
# Instead of hardcoding the complete S3 path for every dataset,
# we dynamically construct it using the centralized configuration.
# This makes the pipeline reusable for all datasets.

SOURCE_PATH = f"{RAW_DATA_PATH}/{SOURCE_FILE}"

print("Source Path Generated Successfully\n")

print(f"Dataset : {DATASET_NAME}")
print(f"S3 Path : {SOURCE_PATH}")

# COMMAND ----------

