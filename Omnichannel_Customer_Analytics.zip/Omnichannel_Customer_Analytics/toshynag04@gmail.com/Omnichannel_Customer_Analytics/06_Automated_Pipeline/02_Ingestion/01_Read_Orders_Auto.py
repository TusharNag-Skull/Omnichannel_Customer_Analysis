# Databricks notebook source
# MAGIC %md
# MAGIC # Automated Orders Ingestion
# MAGIC
# MAGIC ## Purpose
# MAGIC
# MAGIC This notebook automatically reads the Orders dataset from Amazon S3 using the centralized project configuration.
# MAGIC
# MAGIC Unlike the manual pipeline, this notebook does not contain hardcoded storage paths.
# MAGIC
# MAGIC All required configurations are imported from the Project Configuration notebook, making the pipeline reusable, scalable, and production-ready.
# MAGIC
# MAGIC ### Workflow
# MAGIC
# MAGIC Project Configuration
# MAGIC
# MAGIC ↓
# MAGIC
# MAGIC Read Orders Dataset from Amazon S3
# MAGIC
# MAGIC ↓
# MAGIC
# MAGIC Display Schema
# MAGIC
# MAGIC ↓
# MAGIC
# MAGIC Validate Dataset
# MAGIC
# MAGIC ↓
# MAGIC
# MAGIC Pass Data to Bronze Layer

# COMMAND ----------

# MAGIC %run ../01_Config/00_Project_Config

# COMMAND ----------

# MAGIC %md
# MAGIC # Read Orders Dataset
# MAGIC
# MAGIC ## Purpose
# MAGIC
# MAGIC This step reads the Orders dataset from Amazon S3.
# MAGIC
# MAGIC Unlike the manual pipeline, the storage location is not hardcoded.
# MAGIC
# MAGIC The file path is generated dynamically using the centralized project configuration.
# MAGIC
# MAGIC This makes the notebook reusable and easier to maintain.
# MAGIC
# MAGIC ### Workflow
# MAGIC
# MAGIC Project Configuration
# MAGIC
# MAGIC ↓
# MAGIC
# MAGIC Generate Dataset Path
# MAGIC
# MAGIC ↓
# MAGIC
# MAGIC Read Dataset
# MAGIC
# MAGIC ↓
# MAGIC
# MAGIC Create Spark DataFrame

# COMMAND ----------

# ============================================================
# Read Orders Dataset
# ============================================================

# Why?
# -----
# The raw dataset path is generated dynamically using
# the centralized project configuration.
#
# This avoids hardcoded S3 paths inside the notebook.
#
# If the storage location changes in the future,
# only the configuration notebook needs to be updated.
# ============================================================


# ============================================================
# Generate Orders Dataset Path
# ============================================================

orders_file_path = f"{RAW_DATA_PATH}/olist_orders_dataset.csv"

print(f"Orders Dataset Path : {orders_file_path}")


# ============================================================
# Read Orders Dataset
# ============================================================

orders_df = (
    spark.read
         .option("header", "true")
         .option("inferSchema", "true")
         .csv(orders_file_path)
)


print("\nOrders dataset loaded successfully.")

orders_df

# COMMAND ----------

# MAGIC %md
# MAGIC # Initial Dataset Inspection
# MAGIC
# MAGIC ## Purpose
# MAGIC
# MAGIC This step performs an initial inspection of the Orders dataset after it has been loaded into Spark.
# MAGIC
# MAGIC The inspection helps validate that:
# MAGIC
# MAGIC - The dataset has been read successfully.
# MAGIC - The expected number of records are available.
# MAGIC - The schema has been inferred correctly.
# MAGIC - The columns match the source dataset.
# MAGIC
# MAGIC Performing this validation early helps identify data quality or ingestion issues before the pipeline continues.

# COMMAND ----------

# ============================================================
# Initial Dataset Inspection
# ============================================================

# Why?
# -----
# Before processing any dataset, we verify that it has been
# loaded correctly.
#
# This helps confirm:
# 1. Record count
# 2. Number of columns
# 3. Schema
# 4. Sample data
#
# Detecting issues early prevents failures in downstream stages.
# ============================================================


print(f"Total Records : {orders_df.count()}")
print(f"Total Columns : {len(orders_df.columns)}")

print("\nSchema Information")
orders_df.printSchema()

print("\nSample Records")
display(orders_df.limit(10))

# COMMAND ----------

# MAGIC %md
# MAGIC # Dataset Metadata
# MAGIC
# MAGIC ## Purpose
# MAGIC
# MAGIC This step captures basic metadata about the dataset after ingestion.
# MAGIC
# MAGIC The metadata provides a quick overview of the dataset and can be used for:
# MAGIC
# MAGIC - Pipeline monitoring
# MAGIC - Execution logging
# MAGIC - Audit reports
# MAGIC - Operational dashboards
# MAGIC
# MAGIC Capturing metadata at the beginning of the pipeline helps validate that the correct dataset has been loaded before further processing.

# COMMAND ----------

# ============================================================
# Dataset Metadata
# ============================================================

# Why?
# -----
# Capture important information about the dataset
# before any processing begins.
#
# This metadata can later be stored in audit tables
# or execution logs.
# ============================================================


dataset_metadata = {
    "dataset_name": "Orders",
    "source_path": orders_file_path,
    "record_count": orders_df.count(),
    "column_count": len(orders_df.columns),
    "columns": orders_df.columns
}

print("Dataset Metadata\n")

for key, value in dataset_metadata.items():
    print(f"{key} : {value}")

# COMMAND ----------

# MAGIC %md
# MAGIC # Dataset Parameters
# MAGIC
# MAGIC ## Purpose
# MAGIC
# MAGIC Instead of hardcoding dataset-specific values throughout the notebook, we define them once as parameters.
# MAGIC
# MAGIC This makes the notebook reusable for multiple datasets.
# MAGIC
# MAGIC By changing only the dataset parameters, the same notebook can ingest Orders, Customers, Payments, Reviews, Sellers, Products, or any future dataset without modifying the pipeline logic.

# COMMAND ----------

# ============================================================
# Dataset Parameters
# ============================================================

DATASET_NAME = "orders"

SOURCE_FILE = "olist_orders_dataset.csv"

BRONZE_TABLE = "orders"

SILVER_TABLE = "orders"

print("Dataset Parameters Loaded Successfully\n")

print(f"Dataset Name : {DATASET_NAME}")
print(f"Source File  : {SOURCE_FILE}")
print(f"Bronze Table : {BRONZE_TABLE}")
print(f"Silver Table : {SILVER_TABLE}")

# COMMAND ----------

# MAGIC %md
# MAGIC # Create Generic Dataset Variables
# MAGIC
# MAGIC ## Purpose
# MAGIC
# MAGIC This step converts the dataset-specific variables into generic variables.
# MAGIC
# MAGIC Rather than referring to Orders throughout the notebook, generic variables are created so that the same notebook can process any dataset.
# MAGIC
# MAGIC This significantly improves maintainability and reusability.
# MAGIC
# MAGIC ### Current Flow
# MAGIC
# MAGIC Orders Dataset
# MAGIC
# MAGIC ↓
# MAGIC
# MAGIC orders_df
# MAGIC
# MAGIC ↓
# MAGIC
# MAGIC Generic Dataset
# MAGIC
# MAGIC ↓
# MAGIC
# MAGIC source_file_path
# MAGIC
# MAGIC ↓
# MAGIC
# MAGIC source_df

# COMMAND ----------

# ============================================================
# Verify Generic Dataset
# ============================================================

# Why?
# -----
# Validate the generic DataFrame before continuing.
#
# The pipeline will no longer reference dataset-specific
# variables such as orders_df.
#
# Every subsequent step will operate on source_df.
# ============================================================

print(f"Dataset Name : {DATASET_NAME}")
print(f"Source File  : {SOURCE_FILE}")

print(f"\nTotal Records : {source_df.count()}")
print(f"Total Columns : {len(source_df.columns)}")

print("\nSchema Information")
source_df.printSchema()

print("\nSample Records")
display(source_df.limit(10))

# COMMAND ----------

