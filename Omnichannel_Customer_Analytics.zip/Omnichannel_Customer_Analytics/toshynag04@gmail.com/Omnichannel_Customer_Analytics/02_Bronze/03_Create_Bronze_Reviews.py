# Databricks notebook source
# ============================================================================
# STEP 1 : Read the Reviews Data from AWS S3
#
# Why?
# ----
# Since each notebook runs independently in Databricks, we read the source
# file again before loading it into the Bronze layer.
#
# Bronze stores the raw source data exactly as received, without applying
# any business transformations.
#
# The Reviews dataset contains quoted text and multiline review comments,
# so we enable the required CSV options to parse it correctly.
# ============================================================================

order_reviews_df = (
    spark.read
        .option("header", "true")
        .option("inferSchema", "true")
        .option("quote", '"')
        .option("escape", '"')
        .option("multiLine", "true")
        .csv("s3://omnicapstone/raw_data/olist_order_reviews_dataset.csv")
)

order_reviews_df

# COMMAND ----------

spark.sql("""
CREATE SCHEMA IF NOT EXISTS workspace.bronze
""")

print("✅ Bronze schema is ready.")

# COMMAND ----------

# ============================================================================
# STEP 3 : Create Bronze Reviews Delta Table
#
# Why?
# ----
# The Bronze layer stores the raw source data exactly as received from AWS S3.
#
# We create a Delta table so that the data benefits from:
#
# • ACID Transactions
# • Time Travel
# • Schema Enforcement
# • Version History
# • Efficient Reads
#
# No cleaning or transformations are performed at this stage.
# ============================================================================

spark.sql("""

CREATE TABLE IF NOT EXISTS workspace.bronze.order_reviews
(

    review_id STRING,
    order_id STRING,
    review_score INT,
    review_comment_title STRING,
    review_comment_message STRING,
    review_creation_date TIMESTAMP,
    review_answer_timestamp TIMESTAMP

)

USING DELTA

""")

print("✅ Bronze Order Reviews Delta table created successfully.")

# COMMAND ----------

spark.table("workspace.bronze.order_reviews").printSchema()

# COMMAND ----------

# ============================================================================
# STEP 4 : Load Reviews Data into the Bronze Delta Table
#
# Why?
# ----
# This step writes the raw Reviews dataset into the Bronze Delta table.
#
# Since this is the first layer of the Medallion Architecture,
# the data is stored exactly as received without any modifications.
# ============================================================================

order_reviews_df.write \
    .mode("overwrite") \
    .insertInto("workspace.bronze.order_reviews")

print("✅ Order Reviews data successfully loaded into the Bronze Delta table.")

# COMMAND ----------

# ============================================================================
# STEP 5 : Verify Bronze Table
#
# Why?
# ----
# Read the Bronze Delta table back from Unity Catalog to confirm that
# the data has been loaded successfully.
# ============================================================================

bronze_order_reviews_df = spark.table("workspace.bronze.order_reviews")

display(bronze_order_reviews_df)

# COMMAND ----------

# ============================================================================
# STEP 6 : Validate Record Count
#
# Why?
# ----
# Compare the source record count with the Bronze table count to ensure
# that no records were lost during the loading process.
# ============================================================================

source_count = order_reviews_df.count()
bronze_count = bronze_order_reviews_df.count()

print(f"Source Records : {source_count}")
print(f"Bronze Records : {bronze_count}")

if source_count == bronze_count:
    print("✅ Validation Passed: Row counts match.")
else:
    print("❌ Validation Failed: Row counts do not match.")

# COMMAND ----------

# MAGIC %sql
# MAGIC
# MAGIC DESCRIBE HISTORY workspace.bronze.order_reviews; -- Checking for the history what we did

# COMMAND ----------

# MAGIC %sql
# MAGIC
# MAGIC SHOW TABLES IN workspace.bronze;

# COMMAND ----------

dbutils.fs.rm("s3://omnicapstone/bronze_tables/order_reviews", True)

# COMMAND ----------

# ============================================================================
# STEP 9 : Export Bronze Reviews Delta Table to AWS S3
#
# Why?
# ----
# Besides registering the Delta table in Unity Catalog,
# we also store its physical Delta files in Amazon S3.
#
# This ensures:
#
# • Durable cloud storage
# • Easy access for downstream pipelines
# • Backup of the Bronze layer
# • Separation between catalog metadata and physical storage
# ============================================================================

# Read Bronze Delta table
bronze_order_reviews_df = spark.table("workspace.bronze.order_reviews")

# Export Delta files to AWS S3
bronze_order_reviews_df.write \
    .format("delta") \
    .mode("overwrite") \
    .save("s3://omnicapstone/bronze_tables/order_reviews")

print("✅ Bronze Order Reviews Delta table exported to S3 successfully.")

# COMMAND ----------

# MAGIC %md
# MAGIC # Bronze Layer - Order Reviews
# MAGIC
# MAGIC # Overview
# MAGIC
# MAGIC The Bronze layer is the first storage layer in the Medallion Architecture.
# MAGIC
# MAGIC Its primary purpose is to preserve the raw source data exactly as it was received from the ingestion layer without applying any business transformations or business-level data cleansing.
# MAGIC
# MAGIC The Order Reviews dataset was read from Amazon S3, stored as a Delta table inside the Bronze schema, validated, and exported back to Amazon S3 as Delta files.
# MAGIC
# MAGIC ---
# MAGIC
# MAGIC # Important Update
# MAGIC
# MAGIC During the initial implementation, an issue was identified while reading the **Order Reviews** CSV file.
# MAGIC
# MAGIC The dataset contains:
# MAGIC
# MAGIC - Quoted review comments
# MAGIC - Commas inside review messages
# MAGIC - Multi-line review text
# MAGIC
# MAGIC Initially, the dataset was read using only:
# MAGIC
# MAGIC ```python
# MAGIC .option("header", "true")
# MAGIC .option("inferSchema", "true")
# MAGIC ```
# MAGIC
# MAGIC Because Spark was not instructed how to handle quoted and multiline text, several rows were parsed incorrectly.
# MAGIC
# MAGIC This caused:
# MAGIC
# MAGIC - Columns to shift
# MAGIC - Timestamp values appearing inside the `review_score` column
# MAGIC - Incorrect record count (104,162)
# MAGIC - Incorrect datatypes (many columns became STRING)
# MAGIC - Data quality validations to fail during the Silver layer.
# MAGIC
# MAGIC To resolve this issue, the CSV reader was updated with the following options:
# MAGIC
# MAGIC ```python
# MAGIC .option("quote", "\"")
# MAGIC .option("escape", "\"")
# MAGIC .option("multiLine", "true")
# MAGIC ```
# MAGIC
# MAGIC After applying these options:
# MAGIC
# MAGIC - Review comments were parsed correctly.
# MAGIC - Column alignment was restored.
# MAGIC - Datatypes were inferred correctly.
# MAGIC - Record count became **99,224**, which matches the actual dataset.
# MAGIC - The Bronze table was recreated using the corrected source data.
# MAGIC
# MAGIC ---
# MAGIC
# MAGIC # Steps Performed
# MAGIC
# MAGIC ## Step 1 : Read the Reviews Dataset
# MAGIC
# MAGIC The raw Order Reviews dataset was read from the AWS S3 bucket into a Spark DataFrame.
# MAGIC
# MAGIC Since the dataset contains quoted text and multiline review comments, additional CSV parsing options were enabled to correctly interpret the file.
# MAGIC
# MAGIC ### Source Location
# MAGIC
# MAGIC ```
# MAGIC s3://omnicapstone/raw_data/olist_order_reviews_dataset.csv
# MAGIC ```
# MAGIC
# MAGIC No business transformations or data cleansing were performed during this step.
# MAGIC
# MAGIC ---
# MAGIC
# MAGIC ## Step 2 : Create Bronze Schema
# MAGIC
# MAGIC A Bronze schema was created (if it did not already exist).
# MAGIC
# MAGIC ```
# MAGIC workspace.bronze
# MAGIC ```
# MAGIC
# MAGIC Using
# MAGIC
# MAGIC ```sql
# MAGIC CREATE SCHEMA IF NOT EXISTS
# MAGIC ```
# MAGIC
# MAGIC ensures that the notebook can be executed multiple times without errors.
# MAGIC
# MAGIC ---
# MAGIC
# MAGIC ## Step 3 : Create Bronze Order Reviews Delta Table
# MAGIC
# MAGIC A Delta table named
# MAGIC
# MAGIC ```
# MAGIC workspace.bronze.order_reviews
# MAGIC ```
# MAGIC
# MAGIC was created to store the raw Order Reviews dataset.
# MAGIC
# MAGIC The table structure exactly matches the correctly parsed source dataset.
# MAGIC
# MAGIC ### Columns Stored
# MAGIC
# MAGIC | Column | Data Type |
# MAGIC |----------|-----------|
# MAGIC | review_id | STRING |
# MAGIC | order_id | STRING |
# MAGIC | review_score | INT |
# MAGIC | review_comment_title | STRING |
# MAGIC | review_comment_message | STRING |
# MAGIC | review_creation_date | TIMESTAMP |
# MAGIC | review_answer_timestamp | TIMESTAMP |
# MAGIC
# MAGIC No business-level transformations, filtering, or cleaning were performed.
# MAGIC
# MAGIC The Bronze layer simply preserves the source data exactly as it was correctly parsed.
# MAGIC
# MAGIC ---
# MAGIC
# MAGIC ## Step 4 : Load Data into Bronze Delta Table
# MAGIC
# MAGIC The complete Order Reviews dataset was written into the Bronze Delta table using **Overwrite** mode.
# MAGIC
# MAGIC No filtering, deduplication, or business logic was applied.
# MAGIC
# MAGIC This guarantees that the Bronze layer remains an exact representation of the source data.
# MAGIC
# MAGIC ---
# MAGIC
# MAGIC ## Step 5 : Verify the Bronze Table
# MAGIC
# MAGIC The newly created Delta table was read back from Unity Catalog.
# MAGIC
# MAGIC This verification confirmed:
# MAGIC
# MAGIC - Table creation was successful.
# MAGIC - Data was loaded correctly.
# MAGIC - Schema matched the source dataset.
# MAGIC - Records were accessible through Unity Catalog.
# MAGIC
# MAGIC ---
# MAGIC
# MAGIC ## Step 6 : Validate Record Count
# MAGIC
# MAGIC The number of records in the source DataFrame was compared with the Bronze Delta table.
# MAGIC
# MAGIC ### Validation Results
# MAGIC
# MAGIC | Source Records | Bronze Records |
# MAGIC |----------------|---------------|
# MAGIC | **99,224** | **99,224** |
# MAGIC
# MAGIC The row counts matched exactly, confirming that no records were lost during the Bronze loading process.
# MAGIC
# MAGIC ---
# MAGIC
# MAGIC ## Step 7 : Review Delta Table History
# MAGIC
# MAGIC The Delta transaction history was examined using:
# MAGIC
# MAGIC ```sql
# MAGIC DESCRIBE HISTORY workspace.bronze.order_reviews;
# MAGIC ```
# MAGIC
# MAGIC This verifies that every write operation performed on the Delta table is recorded.
# MAGIC
# MAGIC The history includes:
# MAGIC
# MAGIC - Version Number
# MAGIC - Operation Type
# MAGIC - Timestamp
# MAGIC - User Information
# MAGIC - Operation Parameters
# MAGIC
# MAGIC This provides:
# MAGIC
# MAGIC - Auditability
# MAGIC - Version Control
# MAGIC - Time Travel support
# MAGIC
# MAGIC ---
# MAGIC
# MAGIC ## Step 8 : Verify Bronze Table Registration
# MAGIC
# MAGIC The Bronze schema was inspected using:
# MAGIC
# MAGIC ```sql
# MAGIC SHOW TABLES IN workspace.bronze;
# MAGIC ```
# MAGIC
# MAGIC This confirmed that the table
# MAGIC
# MAGIC ```
# MAGIC order_reviews
# MAGIC ```
# MAGIC
# MAGIC was successfully registered inside Unity Catalog.
# MAGIC
# MAGIC ---
# MAGIC
# MAGIC ## Step 9 : Export Bronze Delta Table to Amazon S3
# MAGIC
# MAGIC The Bronze Delta table was exported as Delta files to Amazon S3.
# MAGIC
# MAGIC ### Export Location
# MAGIC
# MAGIC ```
# MAGIC s3://omnicapstone/bronze_tables/order_reviews/
# MAGIC ```
# MAGIC
# MAGIC Exporting the physical Delta files provides:
# MAGIC
# MAGIC - Durable cloud storage
# MAGIC - Backup of the Bronze layer
# MAGIC - Easy access for downstream pipelines
# MAGIC - Separation of Unity Catalog metadata from physical storage
# MAGIC
# MAGIC ---
# MAGIC
# MAGIC # Bronze Layer Summary
# MAGIC
# MAGIC The Bronze layer now contains a correctly parsed and complete copy of the raw Order Reviews dataset stored in Delta format.
# MAGIC
# MAGIC ### Unity Catalog Table
# MAGIC
# MAGIC ```
# MAGIC workspace.bronze.order_reviews
# MAGIC ```
# MAGIC
# MAGIC ### Physical Storage
# MAGIC
# MAGIC ```
# MAGIC s3://omnicapstone/bronze_tables/order_reviews/
# MAGIC ```
# MAGIC
# MAGIC ---
# MAGIC
# MAGIC # Data Quality Status
# MAGIC
# MAGIC The Bronze layer intentionally preserves the source data without applying business transformations.
# MAGIC
# MAGIC Although the CSV parsing issue has been corrected, the Bronze layer still retains any genuine data quality issues present in the source dataset, including:
# MAGIC
# MAGIC - Missing review IDs
# MAGIC - Missing order IDs
# MAGIC - Missing review titles
# MAGIC - Missing review messages
# MAGIC - Missing timestamps
# MAGIC - Duplicate records
# MAGIC
# MAGIC These issues are expected and will be handled during the Silver layer.
# MAGIC
# MAGIC ---
# MAGIC
# MAGIC # Outcome
# MAGIC
# MAGIC At the end of this notebook:
# MAGIC
# MAGIC - The raw Order Reviews dataset was successfully read using the correct CSV parsing options.
# MAGIC - The earlier parsing issue caused by quoted and multiline review comments was resolved.
# MAGIC - The dataset was stored as a Delta table in the Bronze schema.
# MAGIC - Record counts were successfully validated.
# MAGIC - Delta transaction history was available.
# MAGIC - The table was registered in Unity Catalog.
# MAGIC - Physical Delta files were exported to Amazon S3.
# MAGIC
# MAGIC The dataset is now correctly prepared for cleansing, standardization, and data quality improvements in the Silver layer.

# COMMAND ----------

spark.table("workspace.bronze.order_reviews").printSchema()

# COMMAND ----------

# MAGIC %sql
# MAGIC
# MAGIC DROP TABLE workspace.bronze.order_reviews;

# COMMAND ----------

