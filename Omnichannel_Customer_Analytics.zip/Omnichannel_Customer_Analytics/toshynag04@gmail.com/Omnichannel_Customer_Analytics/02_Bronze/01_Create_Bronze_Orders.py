# Databricks notebook source
# ============================================================================
# STEP 1 : Read the Orders Dataset from AWS S3
# ============================================================================
#
# Objective
# ---------
# Read the raw Orders dataset from the AWS S3 bucket into a PySpark DataFrame.
#
# Why are we reading the file again?
# ----------------------------------
# Each notebook in a production data pipeline should be independent.
# This notebook should not rely on variables created in another notebook.
# By reading the source file here, this notebook can run independently
# as part of an automated Databricks Workflow or Lakeflow Job.
#
# Why inferSchema=True?
# ---------------------
# Spark automatically detects the data type of each column
# (String, Integer, Timestamp, etc.), eliminating the need to
# manually define the schema for this CSV file.
#
# Input
# -----
# AWS S3 Bucket
# s3://omnicapstone/raw_data/olist_orders_dataset.csv
#
# Output
# ------
# orders_df : PySpark DataFrame
#
# ============================================================================

orders_df = (
    spark.read
         .option("header", "true")          # Uses the first row of the CSV as column names
         .option("inferSchema", "true")     # Automatically detects the datatype of each column
         .csv("s3://omnicapstone/raw_data/olist_orders_dataset.csv")
)

# COMMAND ----------

# MAGIC %md
# MAGIC # STEP 2
# MAGIC
# MAGIC ## Create the Bronze Schema
# MAGIC
# MAGIC Before storing the raw data, we create a dedicated Bronze schema.
# MAGIC
# MAGIC A schema acts as a logical container for related tables.
# MAGIC
# MAGIC Instead of storing every table inside the default schema, we organize the project using the Medallion Architecture.
# MAGIC
# MAGIC **Bronze Schema Responsibilities**
# MAGIC
# MAGIC - Store raw data exactly as received.
# MAGIC - Preserve source data without any transformations.
# MAGIC - Act as the source for the Silver layer.

# COMMAND ----------

# ============================================================================
# STEP 2 : Create the Bronze Schema
# ============================================================================
#
# Objective
# ---------
# Create a dedicated schema for storing Bronze layer tables.
#
# Why?
# ----
# Organizing tables into separate schemas makes the project
# easier to maintain and follows the Medallion Architecture.
#
# Bronze Schema
# -------------
# • Stores raw data only
# • No transformations
# • Serves as the source for the Silver layer
#
# The IF NOT EXISTS clause ensures that rerunning the notebook
# does not produce an error if the schema has already been created.
# ============================================================================

spark.sql("""
CREATE SCHEMA IF NOT EXISTS workspace.bronze
""")

print("✅ Bronze schema is ready.")

# COMMAND ----------

# MAGIC %md
# MAGIC # STEP 3
# MAGIC
# MAGIC ## Create the Bronze Orders Delta Table
# MAGIC
# MAGIC In this step, we create the Bronze Delta table that will store the raw Orders data.
# MAGIC
# MAGIC The table is created before loading any data. This provides better control over the table structure and follows enterprise data engineering practices.
# MAGIC
# MAGIC At this stage, the table is empty.

# COMMAND ----------

# ============================================================================
# STEP 3 : Create the Bronze Orders Delta Table
# ============================================================================
#
# Objective
# ---------
# Create an empty Delta table in the Bronze schema.
#
# Why create the table before loading data?
# -----------------------------------------
# In enterprise projects, table creation and data loading are
# treated as separate operations.
#
# This approach provides:
# • Better governance
# • Controlled schema management
# • Easier maintenance
# • Cleaner ETL pipelines
#
# Table Type
# ----------
# Managed Delta Table
#
# Data Source
# -----------
# Orders Dataset
#
# ============================================================================
# Here we explicitely made the table as if the spark would have created the table then if the csv changes in future then automatically the csv will change and we will not be having cntrol on that and thus schema governance is needed

spark.sql("""
CREATE TABLE IF NOT EXISTS workspace.bronze.orders (

    order_id STRING,
    customer_id STRING,
    order_status STRING,
    order_purchase_timestamp TIMESTAMP,
    order_approved_at TIMESTAMP,
    order_delivered_carrier_date TIMESTAMP,
    order_delivered_customer_date TIMESTAMP,
    order_estimated_delivery_date TIMESTAMP

)
USING DELTA
""")

print("✅ Bronze Orders Delta table created successfully.")

# COMMAND ----------

# MAGIC %md
# MAGIC # STEP 4
# MAGIC
# MAGIC ## Load Raw Data into the Bronze Delta Table
# MAGIC
# MAGIC In this step, we load the raw Orders dataset into the Bronze Delta table.
# MAGIC
# MAGIC The data is inserted exactly as received from AWS S3.
# MAGIC
# MAGIC No transformations, filtering, or cleaning are performed.
# MAGIC
# MAGIC This ensures the Bronze layer remains an immutable copy of the source data.

# COMMAND ----------

# ============================================================================
# STEP 4 : Load Data into the Bronze Orders Table
# ============================================================================
#
# Objective
# ---------
# Load the raw Orders dataset into the Bronze Delta table.
#
# Why?
# ----
# The Bronze layer should contain an exact copy of the source data.
#
# Since the table has already been created, we only need to insert
# the data into it.
#
# No transformations are performed.
#
# Write Mode
# ----------
# Overwrite
#
# During development, overwrite mode allows us to rerun the notebook
# without manually deleting old data.
#
# In production, incremental loading or MERGE operations are
# typically used instead.
# ============================================================================

orders_df.write \
    .mode("overwrite") \
    .insertInto("workspace.bronze.orders")

print("✅ Orders data successfully loaded into the Bronze table.")

# COMMAND ----------

# ============================================================================
# STEP 5 : Validate the Bronze Orders Table
# ============================================================================
#
# Objective
# ---------
# Verify that the Orders data has been successfully written
# to the Bronze Delta table.
#
# Why?
# ----
# A successful write operation does not guarantee that the
# expected data has been stored correctly.
#
# Validation ensures:
# • The table exists.
# • Records are readable.
# • The Bronze layer is ready for downstream processing.
#
# ============================================================================

bronze_orders_df = spark.table("workspace.bronze.orders")

display(bronze_orders_df)

# COMMAND ----------

# ============================================================================
# STEP 6 : Validate the Bronze Table Row Count
# ============================================================================
#
# Objective
# ---------
# Verify that the number of records in the Bronze Delta table
# matches the number of records in the source CSV.
#
# Why?
# ----
# Row count validation is one of the most important quality checks
# performed after loading data.
#
# A mismatch may indicate:
# • Missing records
# • Duplicate records
# • Failed writes
# • Corrupted ingestion
#
# ============================================================================

# Count records in the Bronze table
bronze_count = bronze_orders_df.count()

# Count records in the source DataFrame
source_count = orders_df.count()

print(f"Source Records : {source_count}")
print(f"Bronze Records : {bronze_count}")

# Compare both counts
if source_count == bronze_count:
    print("✅ Validation Passed: Row counts match.")
else:
    print("❌ Validation Failed: Row counts do not match.")

# COMMAND ----------

# MAGIC %sql DESCRIBE HISTORY workspace.bronze.orders

# COMMAND ----------

# MAGIC %md
# MAGIC # STEP 8
# MAGIC
# MAGIC ## Verify the Bronze Table Exists
# MAGIC
# MAGIC Verify that the Bronze Orders table has been successfully created in the Bronze schema.
# MAGIC
# MAGIC This confirms that the table is registered in the Unity Catalog metastore and is available for downstream processing.

# COMMAND ----------

# MAGIC %sql SHOW TABLES IN workspace.bronze

# COMMAND ----------

# Read Bronze Delta table from Unity Catalog
bronze_orders_df = spark.table("workspace.bronze.orders")

# COMMAND ----------

# ============================================================================
# Export Bronze Orders Delta Table to AWS S3
# ============================================================================

bronze_orders_df.write \
    .format("delta") \
    .mode("overwrite") \
    .save("s3://omnicapstone/bronze_tables/orders")

print("✅ Bronze Orders Delta table exported successfully.")

# COMMAND ----------

# ============================================================================
# Validate Bronze Delta Export to AWS S3
#
# Why?
# ----
# Read the exported Delta files back from S3 and compare the
# record count with the Unity Catalog Bronze table.
#
# This ensures that the export completed successfully without
# any data loss.
# ============================================================================

bronze_orders_s3_df = (
    spark.read
         .format("delta")
         .load("s3://omnicapstone/bronze_tables/orders")
)

# Compare record counts
bronze_uc_count = bronze_orders_df.count()
bronze_s3_count = bronze_orders_s3_df.count()

print(f"Unity Catalog Bronze Records : {bronze_uc_count}")
print(f"S3 Bronze Records            : {bronze_s3_count}")

if bronze_uc_count == bronze_s3_count:
    print("✅ Validation Passed: Bronze export is successful.")
else:
    print("❌ Validation Failed: Record counts do not match.")

# COMMAND ----------

