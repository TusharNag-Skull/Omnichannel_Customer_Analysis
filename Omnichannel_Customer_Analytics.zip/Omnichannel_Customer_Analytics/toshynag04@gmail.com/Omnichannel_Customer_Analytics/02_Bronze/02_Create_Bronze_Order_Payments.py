# Databricks notebook source
# ============================================================================
# STEP 1 : Read Order Payments Dataset from AWS S3
#
# Why?
# ----
# Before creating the Bronze table, we first load the raw CSV from AWS S3.
#
# Bronze is the first layer of the Medallion Architecture and stores the raw
# source data in Delta format without applying business transformations.
#
# The source dataset is read with:
# - Header enabled
# - Automatic datatype inference
# ============================================================================

order_payments_df = (
    spark.read
        .option("header", "true")          # Uses the first row as column names
        .option("inferSchema", "true")     # Automatically detects datatypes
        .csv("s3://omnicapstone/raw_data/olist_order_payments_dataset.csv")
)

# Display the inferred schema
order_payments_df

# COMMAND ----------

# ============================================================================
# STEP 2 : Create Bronze Schema
#
# Why?
# ----
# The Bronze layer stores raw source data in Delta format.
#
# We use "IF NOT EXISTS" so that:
# - The notebook can be executed multiple times safely.
# - No error occurs if the Bronze schema already exists.
# ============================================================================

spark.sql("""

CREATE SCHEMA IF NOT EXISTS workspace.bronze

""")

print("✅ Bronze schema is ready.")

# COMMAND ----------

# ============================================================================
# STEP 3 : Create Bronze Order Payments Delta Table
#
# Why?
# ----
# Before loading data, we create an empty Delta table in the Bronze schema.
#
# This table:
# • Stores the raw Order Payments data.
# • Preserves the original schema from the source.
# • Acts as the Bronze layer in the Medallion Architecture.
#
# We use "CREATE TABLE IF NOT EXISTS" so the notebook can be safely
# re-executed without failing.
# ============================================================================

spark.sql("""

CREATE TABLE IF NOT EXISTS workspace.bronze.order_payments
(
    order_id STRING,
    payment_sequential INT,
    payment_type STRING,
    payment_installments INT,
    payment_value DOUBLE
)

USING DELTA

""")

print("✅ Bronze Order Payments Delta table created successfully.")

# COMMAND ----------

# ============================================================================
# STEP 4 : Load Data into the Bronze Delta Table
#
# Why?
# ----
# Now that the Bronze Delta table exists, we load the raw Order Payments
# dataset into it.
#
# We use:
# - overwrite : replaces existing records when rerunning the notebook.
# - insertInto(): inserts data into the existing Delta table while preserving
#   its schema.
#
# This creates the first persistent version of the raw data inside the
# Bronze layer.
# ============================================================================

order_payments_df.write \
    .mode("overwrite") \
    .insertInto("workspace.bronze.order_payments")

print("✅ Order Payments data successfully loaded into the Bronze Delta table.")

# COMMAND ----------

# ============================================================================
# STEP 5 : Read the Bronze Delta Table
#
# Why?
# ----
# After loading the data, we immediately read it back from the Bronze layer.
#
# This verifies:
# • Data has been successfully written.
# • The table is accessible.
# • The schema has been preserved.
# ============================================================================

bronze_order_payments_df = spark.table("workspace.bronze.order_payments")

display(bronze_order_payments_df)

# COMMAND ----------

# ============================================================================
# STEP 6 : Validate Record Count
#
# Why?
# ----
# One of the simplest yet most important validations in ETL pipelines is
# ensuring that all source records have been loaded into the target table.
#
# If the counts match, we know no records were lost during ingestion.
# ============================================================================

source_count = order_payments_df.count()
bronze_count = bronze_order_payments_df.count()

print(f"Source Records : {source_count}")
print(f"Bronze Records : {bronze_count}")

if source_count == bronze_count:
    print("✅ Validation Passed: Row counts match.")
else:
    print("❌ Validation Failed: Row counts do not match.")

# COMMAND ----------

# ============================================================================
# STEP 7 : View Delta Table History
#
# Why?
# ----
# Delta Lake stores every transaction performed on a Delta table.
#
# This allows us to:
# • View CREATE and WRITE operations.
# • Track who modified the table.
# • Support auditing and time travel.
# ============================================================================

display(
    spark.sql("""
        DESCRIBE HISTORY workspace.bronze.order_payments
    """)
)

# COMMAND ----------

# MAGIC %sql
# MAGIC -- In sql you can write it as
# MAGIC
# MAGIC DESCRIBE HISTORY workspace.bronze.order_payments;

# COMMAND ----------

# MAGIC %sql
# MAGIC -- ============================================================================
# MAGIC -- STEP 8 : Verify Bronze Table Registration
# MAGIC --
# MAGIC -- Why?
# MAGIC -- ----
# MAGIC -- This confirms that the Order Payments table is successfully registered
# MAGIC -- inside the Bronze schema of Unity Catalog.
# MAGIC --
# MAGIC -- Downstream Silver and Gold notebooks will reference this table.
# MAGIC -- ============================================================================
# MAGIC
# MAGIC
# MAGIC
# MAGIC SHOW TABLES IN workspace.bronze;

# COMMAND ----------

# ============================================================================
# STEP 9 : Export Bronze Order Payments Delta Table to AWS S3
#
# Why?
# ----
# Although Unity Catalog manages the Bronze table, we also keep a physical
# Delta copy in AWS S3.
#
# Benefits:
# • Backup
# • Disaster Recovery
# • External Consumption
# • Easy integration with other tools
# ============================================================================

# Read Bronze Delta table from Unity Catalog
bronze_order_payments_df = spark.table("workspace.bronze.order_payments")

# Export as Delta files to AWS S3
bronze_order_payments_df.write \
    .format("delta") \
    .mode("overwrite") \
    .save("s3://omnicapstone/bronze_tables/order_payments")

print("✅ Bronze Order Payments Delta table exported to S3 successfully.")

# COMMAND ----------

